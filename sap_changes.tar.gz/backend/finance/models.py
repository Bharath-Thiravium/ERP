from html import escape
from django.db import models
from django.core.validators import RegexValidator, EmailValidator
from django.core.exceptions import ValidationError
from django.utils import timezone
from authentication.models import Company, CompanyServiceUser
from .unit_models import Unit


def validate_gstin_optional(value):
    """Custom validator for GSTIN that allows blank values"""
    if not value or not value.strip():
        return  # Allow empty GSTIN
    
    import re
    gstin_pattern = r'^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$'
    if not re.match(gstin_pattern, value):
        raise ValidationError('Enter a valid GSTIN number')


class HSNCode(models.Model):
    """HSN (Harmonized System of Nomenclature) codes for goods"""
    code = models.CharField(max_length=100, unique=True, db_index=True)
    description = models.TextField()
    gst_rate = models.DecimalField(max_digits=5, decimal_places=2, default=0.00)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'finance_hsn_codes'
        ordering = ['code']

    def __str__(self):
        return escape(f"{self.code} - {self.description[:50]}")


class SACCode(models.Model):
    """SAC (Services Accounting Code) codes for services"""
    code = models.CharField(max_length=100, unique=True, db_index=True)
    service_name = models.CharField(max_length=255)
    description = models.TextField()
    gst_rate = models.DecimalField(max_digits=5, decimal_places=2, default=0.00)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'finance_sac_codes'
        ordering = ['code']

    def __str__(self):
        return escape(f"{self.code} - {self.service_name}")


# ---------------------------------------------------------------------------
# Finance Numbering system models (per-company, per-module)
# ---------------------------------------------------------------------------
FINANCE_NUMBERING_MODULE_CHOICES = [
    ('quotation', 'Quotation'),
    ('purchase_order', 'Purchase Order'),
    ('proforma_invoice', 'Proforma Invoice'),
    ('invoice', 'Invoice'),
    ('customer_payment', 'Customer Payment'),
    ('purchase_request', 'Purchase Request'),
    ('purchase_payment', 'Purchase Payment'),
    ('vendor_invoice', 'Vendor Invoice'),
    ('customer', 'Customer'),
    ('vendor', 'Vendor'),
    ('product', 'Product'),
]

NUMBERING_RESET_SCOPE_CHOICES = [
    ('never', 'Never'),
    ('yearly', 'Yearly'),
    ('monthly', 'Monthly'),
]


class NumberingRule(models.Model):
    """Per-company numbering configuration for finance modules."""

    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='numbering_rules')
    module = models.CharField(max_length=50, choices=FINANCE_NUMBERING_MODULE_CHOICES)
    template = models.CharField(max_length=255, help_text="Template supporting {PREFIX},{SEP},{YY},{YYYY},{MM},{SEQ}")
    prefix = models.CharField(max_length=50, blank=True, default='')
    separator = models.CharField(max_length=5, blank=True, default='-')
    padding = models.PositiveIntegerField(default=4)
    reset_scope = models.CharField(max_length=10, choices=NUMBERING_RESET_SCOPE_CHOICES, default='never')
    start_from = models.PositiveIntegerField(default=1)
    allow_manual_override = models.BooleanField(default=False)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'finance_numbering_rules'
        indexes = [
            models.Index(fields=['company', 'module'], name='finance_numbering_rule_idx'),
        ]
        constraints = [
            models.UniqueConstraint(
                fields=['company', 'module'],
                name='finance_numbering_rule_company_module_unique',
            ),
        ]

    def __str__(self):
        return f"{self.company_id}:{self.module}"


class NumberingCounter(models.Model):
    """Counters tracked per company, module, and reset scope grouping."""

    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='numbering_counters')
    module = models.CharField(max_length=50)
    scope_key = models.CharField(max_length=20, blank=True, default='')
    next_value = models.PositiveIntegerField(default=1)

    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'finance_numbering_counters'
        indexes = [
            models.Index(fields=['company', 'module', 'scope_key'], name='finance_numbering_counter_idx'),
        ]
        constraints = [
            models.UniqueConstraint(
                fields=['company', 'module', 'scope_key'],
                name='finance_numbering_counter_scope_unique',
            ),
        ]

    def __str__(self):
        return f"{self.company_id}:{self.module}:{self.scope_key}->{self.next_value}"


class Product(models.Model):
    """Product/Service model for finance management"""
    PRODUCT_TYPE_CHOICES = [
        ('product', 'Product (Goods)'),
        ('service', 'Service'),
    ]

    # Unit choices removed - now using dynamic Unit model

    # Basic Information
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='products')
    product_code = models.CharField(max_length=50, unique=True, db_index=True)
    name = models.CharField(max_length=255)
    product_type = models.CharField(max_length=10, choices=PRODUCT_TYPE_CHOICES, default='product')
    description = models.TextField(blank=True)

    # Tax Information
    hsn_code = models.ForeignKey(HSNCode, on_delete=models.SET_NULL, null=True, blank=True, related_name='products')
    sac_code = models.ForeignKey(SACCode, on_delete=models.SET_NULL, null=True, blank=True, related_name='products')
    gst_rate = models.DecimalField(max_digits=5, decimal_places=2, default=0.00)

    # Pricing
    unit = models.CharField(max_length=10, blank=True)  # Keep existing field as is
    unit_ref = models.ForeignKey(Unit, on_delete=models.SET_NULL, null=True, blank=True, related_name='products')  # New dynamic unit
    selling_price = models.DecimalField(max_digits=12, decimal_places=2, default=0.00)
    purchase_price = models.DecimalField(max_digits=12, decimal_places=2, default=0.00)

    # Inventory (for products only)
    track_inventory = models.BooleanField(default=False)
    current_stock = models.DecimalField(max_digits=12, decimal_places=2, default=0.00)
    minimum_stock = models.DecimalField(max_digits=12, decimal_places=2, default=0.00)

    # Status
    is_active = models.BooleanField(default=True)

    # Manual override tracking
    manual_gst_override = models.BooleanField(default=False, help_text="True if GST rate was manually overridden")
    
    # Audit fields
    created_by = models.ForeignKey(CompanyServiceUser, on_delete=models.SET_NULL, null=True, related_name='created_products')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'finance_products'
        ordering = ['-created_at']
        unique_together = ['company', 'product_code']

    def __str__(self):
        return escape(f"{self.product_code} - {self.name}")

    def save(self, *args, **kwargs):
        # Auto-generate product code if not provided
        if not self.product_code:
            try:
                from authentication.utils import generate_auto_code
                # Use product_type specific code generation
                code_type = 'product' if self.product_type == 'product' else 'service'
                self.product_code = generate_auto_code(self.company.id, code_type)
            except Exception as e:
                # Fallback to old system if auto-code fails
                if self.product_type == 'product':
                    # Generate company prefix + PROD codes for products
                    company_prefix = getattr(self.company, 'company_prefix', 'COMP')
                    last_product = Product.objects.filter(
                        company=self.company,
                        product_type='product'
                    ).order_by('-id').first()
                    if last_product and last_product.product_code:
                        # Extract number from existing code
                        import re
                        match = re.search(r'(\d+)$', last_product.product_code)
                        if match:
                            last_number = int(match.group(1))
                            self.product_code = f"{company_prefix}PROD{last_number + 1:02d}"
                        else:
                            self.product_code = f"{company_prefix}PROD01"
                    else:
                        self.product_code = f"{company_prefix}PROD01"
                else:
                    # Generate company prefix + SER codes for services
                    company_prefix = getattr(self.company, 'company_prefix', 'COMP')
                    last_service = Product.objects.filter(
                        company=self.company,
                        product_type='service'
                    ).order_by('-id').first()
                    if last_service and last_service.product_code:
                        # Extract number from existing code
                        import re
                        match = re.search(r'(\d+)$', last_service.product_code)
                        if match:
                            last_number = int(match.group(1))
                            self.product_code = f"{company_prefix}SER{last_number + 1:02d}"
                        else:
                            self.product_code = f"{company_prefix}SER01"
                    else:
                        self.product_code = f"{company_prefix}SER01"

        # Ensure unit field is populated from unit_ref if available
        if self.unit_ref and (not self.unit or self.unit.strip() == ''):
            self.unit = self.unit_ref.code

        # Handle GST rate auto-fill vs manual override
        is_new_instance = self.pk is None
        temp_manual_override = getattr(self, '_manual_gst_override', False)
        
        # For new instances, auto-fill GST rate from HSN/SAC unless manually overridden
        if is_new_instance and not temp_manual_override and not self.manual_gst_override:
            if self.product_type == 'product' and self.hsn_code:
                self.gst_rate = self.hsn_code.gst_rate
            elif self.product_type == 'service' and self.sac_code:
                self.gst_rate = self.sac_code.gst_rate
        
        # For existing instances, respect manual overrides
        elif not is_new_instance:
            try:
                # Get the current product from database
                current_product = Product.objects.get(pk=self.pk)
                expected_gst_rate = None
                
                if self.product_type == 'product' and self.hsn_code:
                    expected_gst_rate = self.hsn_code.gst_rate
                elif self.product_type == 'service' and self.sac_code:
                    expected_gst_rate = self.sac_code.gst_rate
                
                # Check if GST rate was manually changed
                if temp_manual_override or (expected_gst_rate is not None and self.gst_rate != expected_gst_rate):
                    # Mark as manual override and keep the current rate
                    self.manual_gst_override = True
                elif not current_product.manual_gst_override and expected_gst_rate is not None:
                    # Auto-update GST rate if not manually overridden
                    self.gst_rate = expected_gst_rate
                    
            except Product.DoesNotExist:
                # Product doesn't exist yet, treat as new
                if self.product_type == 'product' and self.hsn_code:
                    self.gst_rate = self.hsn_code.gst_rate
                elif self.product_type == 'service' and self.sac_code:
                    self.gst_rate = self.sac_code.gst_rate
        
        # Set manual override flag if temp flag was set
        if temp_manual_override:
            self.manual_gst_override = True

        super().save(*args, **kwargs)


class Customer(models.Model):
    """Customer model for Finance service with comprehensive details for invoicing"""

    CUSTOMER_TYPE_CHOICES = [
        ('individual', 'Individual'),
        ('business', 'Business'),
        ('government', 'Government'),
        ('ngo', 'NGO/Non-Profit'),
    ]

    BUSINESS_TYPE_CHOICES = [
        ('proprietorship', 'Sole Proprietorship'),
        ('partnership', 'Partnership'),
        ('llp', 'Limited Liability Partnership'),
        ('private_limited', 'Private Limited Company'),
        ('public_limited', 'Public Limited Company'),
        ('trust', 'Trust'),
        ('society', 'Society'),
        ('cooperative', 'Cooperative Society'),
        ('other', 'Other'),
    ]

    # Basic Information
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='finance_customers')
    created_by = models.ForeignKey(CompanyServiceUser, on_delete=models.CASCADE, related_name='created_customers', null=True, blank=True)
    customer_code = models.CharField(max_length=40, unique=True, blank=True, help_text="Auto-generated unique customer code (e.g., TC-CUST-2627-001)")

    # Customer Type and Basic Details - MANDATORY FIELDS
    customer_type = models.CharField(max_length=20, choices=CUSTOMER_TYPE_CHOICES, help_text="MANDATORY: Customer type")
    name = models.CharField(max_length=255, help_text="MANDATORY: Customer/Company Name")
    display_name = models.CharField(max_length=255, help_text="MANDATORY: Display name for invoices")

    # Contact Information - MANDATORY PHONE
    email = models.EmailField(validators=[EmailValidator()], blank=True, null=True)
    phone = models.CharField(max_length=15, blank=True, null=True, help_text="Primary phone number")
    mobile = models.CharField(max_length=15, blank=True, null=True)
    website = models.URLField(blank=True, null=True)

    # Address Information - MANDATORY BILLING ADDRESS
    billing_address_line1 = models.CharField(max_length=255, help_text="MANDATORY: Billing address line 1")
    billing_address_line2 = models.CharField(max_length=255, blank=True, null=True)
    billing_city = models.CharField(max_length=100, help_text="MANDATORY: Billing city")
    billing_state = models.CharField(max_length=100, help_text="MANDATORY: Billing state")
    billing_pincode = models.CharField(max_length=10, help_text="MANDATORY: Billing PIN code")
    billing_country = models.CharField(max_length=100, default='India')

    # Shipping Address (can be different from billing) - ALL OPTIONAL
    shipping_same_as_billing = models.BooleanField(default=True)
    shipping_address_line1 = models.CharField(max_length=255, blank=True, null=True)
    shipping_address_line2 = models.CharField(max_length=255, blank=True, null=True)
    shipping_city = models.CharField(max_length=100, blank=True, null=True)
    shipping_state = models.CharField(max_length=100, blank=True, null=True)
    shipping_pincode = models.CharField(max_length=10, blank=True, null=True)
    shipping_country = models.CharField(max_length=100, blank=True, null=True)

    # Business Information (for business customers) - ALL OPTIONAL
    business_type = models.CharField(max_length=20, choices=BUSINESS_TYPE_CHOICES, blank=True, null=True)
    industry = models.CharField(max_length=100, blank=True, null=True)

    # Tax Information - GSTIN is OPTIONAL (only required if GST registered)
    gstin = models.CharField(
        max_length=15,
        blank=True,
        null=True,
        validators=[validate_gstin_optional],
        help_text="15-digit GST Identification Number (required only if GST registered)"
    )
    pan_number = models.CharField(
        max_length=10,
        blank=True,
        null=True,
        validators=[RegexValidator(
            regex=r'^[A-Z]{5}[0-9]{4}[A-Z]{1}$',
            message='Enter a valid PAN number'
        )],
        help_text="10-character PAN number"
    )

    # Individual Customer Information - ALL OPTIONAL
    aadhar_number = models.CharField(
        max_length=12,
        blank=True,
        null=True,
        validators=[RegexValidator(
            regex=r'^[0-9]{12}$',
            message='Enter a valid 12-digit Aadhar number'
        )],
        help_text="12-digit Aadhar number (for individuals)"
    )

    # Banking Information - ALL OPTIONAL
    bank_name = models.CharField(max_length=100, blank=True, null=True)
    bank_account_number = models.CharField(max_length=20, blank=True, null=True)
    bank_ifsc_code = models.CharField(
        max_length=11,
        blank=True,
        null=True,
        validators=[RegexValidator(
            regex=r'^[A-Z]{4}0[A-Z0-9]{6}$',
            message='Enter a valid IFSC code'
        )]
    )
    bank_branch = models.CharField(max_length=100, blank=True, null=True)
    account_holder_name = models.CharField(max_length=200, blank=True, null=True)
    
    # Bank Integration Fields
    bank_verification_status = models.CharField(
        max_length=20,
        choices=[
            ('pending', 'Pending'),
            ('verified', 'Verified'),
            ('failed', 'Failed')
        ],
        default='pending'
    )
    bank_verified_date = models.DateTimeField(null=True, blank=True)
    statement_import_enabled = models.BooleanField(default=False)
    last_statement_import = models.DateTimeField(null=True, blank=True)

    # Financial Information - ALL OPTIONAL
    credit_limit = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    payment_terms = models.CharField(max_length=100, blank=True, null=True, help_text="e.g., Net 30, COD, Advance")
    currency = models.CharField(max_length=3, default='INR')
    
    # Opening Balance - ALL OPTIONAL
    opening_balance = models.DecimalField(max_digits=15, decimal_places=2, default=0.00, help_text="Opening balance for this customer")
    opening_balance_date = models.DateField(null=True, blank=True, help_text="Date when opening balance was set")

    # Additional Information - ALL OPTIONAL
    project_area = models.CharField(max_length=255, blank=True, null=True, help_text="Project area or address label for easy identification")
    notes = models.TextField(blank=True, null=True, help_text="Internal notes about the customer")
    is_active = models.BooleanField(default=True)
    
    # Indian Compliance Fields - ALL OPTIONAL
    state_code = models.CharField(max_length=2, blank=True, null=True, help_text="2-digit state code for GST")
    is_gst_registered = models.BooleanField(default=False)
    gst_registration_date = models.DateField(null=True, blank=True)

    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        unique_together = ['company', 'customer_code']
        verbose_name = 'Customer'
        verbose_name_plural = 'Customers'

    def __str__(self):
        from .security_fixes import sanitize_customer_name
        return escape(f"{self.customer_code} - {sanitize_customer_name(self.name)}")

    def clean(self):
        """Validate model fields before saving"""
        from django.core.exceptions import ValidationError
        errors = {}
        
        # MANDATORY FIELDS VALIDATION
        if not self.customer_type or not self.customer_type.strip():
            errors['customer_type'] = 'Customer type is required.'
        
        if not self.name or not self.name.strip():
            errors['name'] = 'Customer name is required.'
        
        if not self.display_name or not self.display_name.strip():
            errors['display_name'] = 'Display name is required.'
        
        # Phone is now optional since email is available
        
        # MANDATORY BILLING ADDRESS VALIDATION
        if not self.billing_address_line1 or not self.billing_address_line1.strip():
            errors['billing_address_line1'] = 'Billing address line 1 is required.'
        
        if not self.billing_city or not self.billing_city.strip():
            errors['billing_city'] = 'Billing city is required.'
        
        if not self.billing_state or not self.billing_state.strip():
            errors['billing_state'] = 'Billing state is required.'
        
        if not self.billing_pincode or not self.billing_pincode.strip():
            errors['billing_pincode'] = 'Billing PIN code is required.'
        
        # MANDATORY GSTIN VALIDATION - Only if GST registered
        if self.is_gst_registered:
            if not self.gstin or not self.gstin.strip():
                errors['gstin'] = 'GSTIN is required for GST registered customers.'
            else:
                import re
                gstin_pattern = r'^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$'
                if not re.match(gstin_pattern, self.gstin):
                    errors['gstin'] = 'Please enter a valid GSTIN (15 characters).'
        elif self.gstin and self.gstin.strip():
            # If GSTIN is provided but not marked as GST registered, validate format
            import re
            gstin_pattern = r'^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$'
            if not re.match(gstin_pattern, self.gstin):
                errors['gstin'] = 'Please enter a valid GSTIN (15 characters).'
        
        # OPTIONAL FIELDS VALIDATION (only if provided)
        if self.email:
            from django.core.validators import validate_email
            try:
                validate_email(self.email)
            except ValidationError:
                errors['email'] = 'Please enter a valid email address.'
        
        if self.pan_number:
            import re
            pan_pattern = r'^[A-Z]{5}[0-9]{4}[A-Z]{1}$'
            if not re.match(pan_pattern, self.pan_number):
                errors['pan_number'] = 'Please enter a valid PAN (10 characters).'
        
        if self.aadhar_number:
            import re
            aadhar_pattern = r'^[0-9]{12}$'
            if not re.match(aadhar_pattern, self.aadhar_number):
                errors['aadhar_number'] = 'Please enter a valid Aadhar number (12 digits).'
        
        if self.bank_ifsc_code:
            import re
            ifsc_pattern = r'^[A-Z]{4}0[A-Z0-9]{6}$'
            if not re.match(ifsc_pattern, self.bank_ifsc_code):
                errors['bank_ifsc_code'] = 'Please enter a valid IFSC code.'
        
        # Validate credit limit
        if self.credit_limit < 0:
            errors['credit_limit'] = 'Credit limit cannot be negative.'
        
        # Validate shipping address logic (only if different from billing)
        if not self.shipping_same_as_billing:
            if not self.shipping_address_line1 or not self.shipping_address_line1.strip():
                errors['shipping_address_line1'] = 'Shipping Address Line 1 is required when shipping address is different from billing address.'
            if not self.shipping_city or not self.shipping_city.strip():
                errors['shipping_city'] = 'Shipping City is required when shipping address is different from billing address.'
            if not self.shipping_state or not self.shipping_state.strip():
                errors['shipping_state'] = 'Shipping State is required when shipping address is different from billing address.'
            if not self.shipping_pincode or not self.shipping_pincode.strip():
                errors['shipping_pincode'] = 'Shipping PIN Code is required when shipping address is different from billing address.'
        
        if errors:
            raise ValidationError(errors)
    
    def save(self, *args, **kwargs):
        # Run model validation
        self.full_clean()
        
        if not self.customer_code:
            try:
                from authentication.utils import generate_auto_code
                self.customer_code = generate_auto_code(self.company.id, 'customer')
            except Exception as e:
                # Fallback to old system if auto-code fails
                max_retries = 10
                for attempt in range(max_retries):
                    try:
                        # Get the highest customer number for this company
                        last_customer = Customer.objects.filter(
                            company=self.company,
                            customer_code__startswith='CUST-'
                        ).order_by('-customer_code').first()
                        
                        if last_customer and last_customer.customer_code:
                            try:
                                last_number = int(last_customer.customer_code.split('-')[-1])
                                new_number = last_number + 1
                            except (ValueError, IndexError):
                                new_number = 1
                        else:
                            new_number = 1
                        
                        self.customer_code = f"CUST-{new_number:06d}"
                        break  # Success, exit retry loop
                        
                    except Exception as e:
                        if 'unique constraint' in str(e).lower() or 'duplicate' in str(e).lower():
                            # If it's a uniqueness error, retry with next number
                            if attempt < max_retries - 1:
                                continue
                            else:
                                # Last attempt failed, use timestamp-based code
                                import time
                                timestamp = int(time.time() * 1000) % 1000000
                                self.customer_code = f"CUST-{timestamp:06d}"
                                break
                        else:
                            # Different error, re-raise
                            raise e
        
        # Display name is now mandatory, but set default if somehow empty
        if not self.display_name:
            self.display_name = self.name
        super().save(*args, **kwargs)

    @property
    def full_billing_address(self):
        """Get formatted billing address"""
        address_parts = [
            self.billing_address_line1,
            self.billing_address_line2,
            self.billing_city,
            self.billing_state,
            self.billing_pincode,
            self.billing_country
        ]
        return ', '.join([part for part in address_parts if part])

    @property
    def full_shipping_address(self):
        """Get formatted shipping address"""
        if self.shipping_same_as_billing:
            return self.full_billing_address

        address_parts = [
            self.shipping_address_line1,
            self.shipping_address_line2,
            self.shipping_city,
            self.shipping_state,
            self.shipping_pincode,
            self.shipping_country or self.billing_country
        ]
        return ', '.join([part for part in address_parts if part])


class CustomerShippingAddress(models.Model):
    """Multiple shipping addresses for customers"""

    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='shipping_addresses')
    label = models.CharField(max_length=100, help_text="Address label (e.g., Warehouse, Branch Office)")

    # Address Information
    address_line1 = models.CharField(max_length=255)
    address_line2 = models.CharField(max_length=255, blank=True)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    pincode = models.CharField(max_length=10)
    country = models.CharField(max_length=100, default='India')

    # Metadata
    is_default = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-is_default', 'label']
        verbose_name = 'Customer Shipping Address'
        verbose_name_plural = 'Customer Shipping Addresses'

    def __str__(self):
        return escape(f"{self.customer.name} - {self.label}")
    
    def save(self, *args, **kwargs):
        """Override save to ensure only one default address per customer"""
        import logging
        logger = logging.getLogger(__name__)
        
        # Log if this is an update to an existing address
        if self.pk:
            try:
                old_address = CustomerShippingAddress.objects.get(pk=self.pk)
                if (old_address.address_line1 != self.address_line1 or 
                    old_address.city != self.city or 
                    old_address.state != self.state or 
                    old_address.pincode != self.pincode):
                    logger.warning(
                        f"Shipping address {self.pk} for customer '{self.customer.name}' is being updated. "
                        f"This will affect all invoices/POs using this address. "
                        f"Old: {old_address.address_line1}, {old_address.city}. "
                        f"New: {self.address_line1}, {self.city}"
                    )
            except CustomerShippingAddress.DoesNotExist:
                pass
        
        if self.is_default:
            # Unset all other defaults for this customer
            CustomerShippingAddress.objects.filter(
                customer=self.customer,
                is_default=True
            ).exclude(pk=self.pk).update(is_default=False)
        super().save(*args, **kwargs)

    @property
    def full_address(self):
        """Get formatted address"""
        address_parts = [
            self.address_line1,
            self.address_line2,
            self.city,
            self.state,
            self.pincode,
            self.country
        ]
        return ', '.join([part for part in address_parts if part])

    def save(self, *args, **kwargs):
        # If this is set as default, unset other defaults for this customer
        if self.is_default:
            CustomerShippingAddress.objects.filter(
                customer=self.customer,
                is_default=True
            ).exclude(pk=self.pk).update(is_default=False)

        super().save(*args, **kwargs)


class Quotation(models.Model):
    """Quotation model for creating quotes for customers"""

    STATUS_CHOICES = [
        ('draft', 'Draft'),
        ('sent', 'Sent'),
        ('confirmed', 'Confirmed'),
        ('approved', 'Approved'),
        ('accepted', 'Accepted'),
        ('rejected', 'Rejected'),
        ('expired', 'Expired'),
        ('converted', 'Converted to Invoice'),
    ]

    GST_TYPE_CHOICES = [
        ('igst', 'IGST (Inter-State)'),
        ('cgst_sgst', 'CGST + SGST (Intra-State)'),
        ('exempt', 'GST Exempt'),
    ]

    # Basic Information
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='quotations')
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='quotations')
    quotation_number = models.CharField(max_length=50, db_index=True)

    # Quotation Details
    quotation_date = models.DateField()
    valid_until = models.DateField()
    reference = models.CharField(max_length=100, blank=True, help_text="Customer reference or PO number")

    # Shipping Address (can be different from customer's default)
    shipping_address = models.ForeignKey(
        CustomerShippingAddress,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        help_text="Selected shipping address for this quotation"
    )

    # GST Information
    gst_type = models.CharField(max_length=20, choices=GST_TYPE_CHOICES)
    customer_gstin = models.CharField(max_length=15, blank=True, help_text="Customer GSTIN at time of quotation")
    company_gstin = models.CharField(max_length=15, blank=True, help_text="Company GSTIN at time of quotation")

    # Financial Totals
    subtotal = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    total_tax = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    total_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)

    # Tax Breakdown (for CGST+SGST)
    cgst_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    sgst_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    igst_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)

    # Additional Charges
    discount_percentage = models.DecimalField(max_digits=5, decimal_places=2, default=0.00)
    discount_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    shipping_charges = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    other_charges = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)

    # TDS Information (to be collected from client)
    tds_applicable = models.BooleanField(default=False, help_text="Whether TDS applies to this quotation")
    tds_percentage = models.DecimalField(max_digits=5, decimal_places=2, default=0.00, help_text="TDS percentage to be collected from client")
    tds_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00, help_text="TDS amount to be collected from client")

    # Status and Notes
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft')
    notes = models.TextField(blank=True, help_text="Internal notes")
    terms_and_conditions = models.TextField(blank=True)

    # Revision tracking
    is_revised = models.BooleanField(default=False, help_text="Whether this quotation has been revised")
    revision_count = models.PositiveIntegerField(default=0, help_text="Number of times this quotation has been revised")
    revised_at = models.DateTimeField(null=True, blank=True, help_text="When this quotation was last revised")
    revised_by = models.ForeignKey(CompanyServiceUser, on_delete=models.SET_NULL, null=True, blank=True, related_name='revised_quotations')

    # Invoice Creation Tracking - NEW FIELDS
    invoice_created = models.BooleanField(default=False, help_text="Whether invoice has been created from this quotation")
    po_created = models.BooleanField(default=False, help_text="Whether PO has been created from this quotation")
    proforma_created = models.BooleanField(default=False, help_text="Whether proforma invoice has been created from this quotation")
    invoice_created_at = models.DateTimeField(null=True, blank=True, help_text="When invoice was created from this quotation")
    po_created_at = models.DateTimeField(null=True, blank=True, help_text="When PO was created from this quotation")

    # Quotation-based Invoice Balance Tracking - NEW FIELDS
    claim_type = models.CharField(
        max_length=20,
        choices=[
            ('percentage', 'Percentage-based Claiming'),
            ('quantity', 'Quantity-based Claiming'),
        ],
        blank=True,
        null=True,
        help_text="How invoices will be claimed from this quotation (set on first invoice creation)"
    )

    proforma_claimed_amount = models.DecimalField(
        max_digits=15,
        decimal_places=2,
        default=0.00,
        help_text="Total amount claimed through proforma invoices from this quotation"
    )

    invoice_claimed_amount = models.DecimalField(
        max_digits=15,
        decimal_places=2,
        default=0.00,
        help_text="Total amount invoiced (final invoices with tax) from this quotation"
    )

    remaining_proforma_balance = models.DecimalField(
        max_digits=15,
        decimal_places=2,
        default=0.00,
        help_text="Remaining amount available for proforma claiming from quotation"
    )

    remaining_invoice_balance = models.DecimalField(
        max_digits=15,
        decimal_places=2,
        default=0.00,
        help_text="Remaining amount to be invoiced (with tax) from quotation"
    )

    # Rejection tracking fields
    is_rejected = models.BooleanField(default=False, help_text="Whether this quotation has been rejected")
    rejection_reason = models.TextField(blank=True, null=True, help_text="Reason for rejection")
    rejected_by = models.ForeignKey(CompanyServiceUser, on_delete=models.SET_NULL, null=True, blank=True, related_name='rejected_quotations')
    rejected_at = models.DateTimeField(null=True, blank=True, help_text="When this quotation was rejected")
    
    # Audit fields
    created_by = models.ForeignKey(CompanyServiceUser, on_delete=models.SET_NULL, null=True, related_name='created_quotations')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'finance_quotations'
        ordering = ['-created_at']
        unique_together = ['company', 'quotation_number']
        indexes = [
            models.Index(fields=['company', 'quotation_number'], name='fin_qt_no_idx'),
        ]

    def __str__(self):
        return escape(f"{self.quotation_number} - {self.customer.name}")

    def save(self, *args, **kwargs):
        # Auto-generate quotation number if not provided
        if not self.quotation_number:
            try:
                from authentication.utils import generate_auto_code
                self.quotation_number = generate_auto_code(self.company.id, 'quotation')
            except Exception as e:
                # Fallback to old system if auto-code fails
                from datetime import datetime
                year = datetime.now().year
                last_quotation = Quotation.objects.filter(
                    company=self.company,
                    quotation_number__startswith=f"QUO-{year}"
                ).order_by('-id').first()

                if last_quotation:
                    last_number = int(last_quotation.quotation_number.split('-')[-1])
                    self.quotation_number = f"QUO-{year}-{last_number + 1:06d}"
                else:
                    self.quotation_number = f"QUO-{year}-000001"

        # Determine GST type based on customer and company GSTIN
        if self.customer.gstin and hasattr(self.company, 'gst_number') and self.company.gst_number:
            customer_state_code = self.customer.gstin[:2]
            company_state_code = self.company.gst_number[:2]

            if customer_state_code == company_state_code:
                self.gst_type = 'cgst_sgst'  # Same state - CGST + SGST
            else:
                self.gst_type = 'igst'  # Different state - IGST
        else:
            self.gst_type = 'exempt'  # No GST if either party doesn't have GSTIN

        # Store GSTIN values at time of quotation
        self.customer_gstin = self.customer.gstin or ''
        self.company_gstin = getattr(self.company, 'gst_number', '') or ''

        super().save(*args, **kwargs)
        
        # Initialize balance tracking for new quotations
        if self.pk and self.subtotal > 0 and self.remaining_proforma_balance == 0 and self.remaining_invoice_balance == 0:
            from decimal import Decimal
            self.remaining_proforma_balance = self.subtotal
            self.remaining_invoice_balance = self.total_amount
            # Mark flags as False initially
            self.invoice_created = False
            self.proforma_created = False
            super().save(update_fields=['remaining_proforma_balance', 'remaining_invoice_balance', 'invoice_created', 'proforma_created'])

    def calculate_totals(self):
        """Calculate quotation totals from line items"""
        from decimal import Decimal

        items = self.quotation_items.all()

        # Initialize all amounts as Decimal - be more careful with conversions
        subtotal = Decimal('0')
        for item in items:
            subtotal += item.line_total
        self.subtotal = subtotal

        # Ensure discount_amount is Decimal - handle existing values more carefully
        if not hasattr(self, 'discount_amount') or self.discount_amount is None:
            self.discount_amount = Decimal('0')
        else:
            # If it's already a Decimal, don't convert it
            if not isinstance(self.discount_amount, Decimal):
                self.discount_amount = Decimal(str(self.discount_amount))

        # Apply discount
        if not hasattr(self, 'discount_percentage') or self.discount_percentage is None:
            discount_percentage = Decimal('0')
        else:
            if not isinstance(self.discount_percentage, Decimal):
                discount_percentage = Decimal(str(self.discount_percentage))
            else:
                discount_percentage = self.discount_percentage

        if discount_percentage > 0:
            self.discount_amount = (self.subtotal * discount_percentage) / Decimal('100')

        discounted_subtotal = self.subtotal - self.discount_amount

        # Calculate tax based on GST type
        total_tax = Decimal('0')
        self.cgst_amount = Decimal('0')
        self.sgst_amount = Decimal('0')
        self.igst_amount = Decimal('0')

        if self.gst_type == 'cgst_sgst':
            # CGST + SGST (each is half of total GST rate)
            for item in items:
                item_tax = (item.line_total * item.gst_rate) / Decimal('100')
                total_tax += item_tax
                self.cgst_amount += item_tax / Decimal('2')
                self.sgst_amount += item_tax / Decimal('2')
        elif self.gst_type == 'igst':
            # IGST (full GST rate)
            for item in items:
                item_tax = (item.line_total * item.gst_rate) / Decimal('100')
                total_tax += item_tax
                self.igst_amount += item_tax

        self.total_tax = total_tax

        # Ensure shipping_charges and other_charges are Decimals - handle existing values carefully
        if not hasattr(self, 'shipping_charges') or self.shipping_charges is None:
            shipping_charges = Decimal('0')
        else:
            if not isinstance(self.shipping_charges, Decimal):
                shipping_charges = Decimal(str(self.shipping_charges))
            else:
                shipping_charges = self.shipping_charges

        if not hasattr(self, 'other_charges') or self.other_charges is None:
            other_charges = Decimal('0')
        else:
            if not isinstance(self.other_charges, Decimal):
                other_charges = Decimal(str(self.other_charges))
            else:
                other_charges = self.other_charges

        # Handle TDS amount - calculate from percentage if provided
        if not hasattr(self, 'tds_percentage') or self.tds_percentage is None:
            tds_percentage = Decimal('0')
        else:
            if not isinstance(self.tds_percentage, Decimal):
                tds_percentage = Decimal(str(self.tds_percentage))
            else:
                tds_percentage = self.tds_percentage

        if tds_percentage > 0:
            self.tds_amount = (discounted_subtotal * tds_percentage) / Decimal('100')
            self.tds_applicable = True
        elif not hasattr(self, 'tds_amount') or self.tds_amount is None:
            self.tds_amount = Decimal('0')
        else:
            if not isinstance(self.tds_amount, Decimal):
                self.tds_amount = Decimal(str(self.tds_amount))
            if self.tds_amount > 0:
                self.tds_applicable = True

        # TDS is deducted by customer from the base amount — it does NOT add to invoice total
        self.total_amount = discounted_subtotal + self.total_tax + shipping_charges + other_charges

        # Ensure shipping_charges and other_charges are saved to the instance
        self.shipping_charges = shipping_charges
        self.other_charges = other_charges

        # Save without triggering calculate_totals again
        super().save(update_fields=[
            'subtotal', 'discount_amount', 'total_tax', 'cgst_amount',
            'sgst_amount', 'igst_amount', 'total_amount', 'tds_applicable', 'tds_amount',
            'shipping_charges', 'other_charges'
        ])

    def update_balance_tracking(self):
        """Update quotation balance tracking after invoice creation"""
        from decimal import Decimal

        # Calculate total proforma claimed amount (subtotal only)
        proforma_subtotal_total = sum(
            proforma.subtotal for proforma in self.proforma_invoices.all()
        ) or Decimal('0')

        # Calculate total tax invoice claimed amount (with tax)
        invoice_total = sum(
            invoice.total_amount for invoice in self.invoices.all()
        ) or Decimal('0')

        # Calculate tax invoice subtotal impact (for cross-impact calculation)
        invoice_subtotal_total = sum(
            invoice.subtotal for invoice in self.invoices.all()
        ) or Decimal('0')

        # Update claimed amounts
        self.proforma_claimed_amount = proforma_subtotal_total
        self.invoice_claimed_amount = invoice_total

        # Cross-impact logic: Tax invoice claiming reduces proforma claimable base
        reduced_proforma_base = self.subtotal - invoice_subtotal_total
        remaining_proforma = max(Decimal('0'), reduced_proforma_base - proforma_subtotal_total)
        
        # Handle rounding precision
        if remaining_proforma < Decimal('5.00'):
            self.remaining_proforma_balance = Decimal('0.00')
        else:
            self.remaining_proforma_balance = remaining_proforma

        # For tax invoice: remaining from total amount (with tax) minus what's already invoiced
        remaining_balance = self.total_amount - invoice_total
        
        # Handle rounding precision
        if remaining_balance < Decimal('5.00'):
            self.remaining_invoice_balance = Decimal('0.00')
        else:
            self.remaining_invoice_balance = remaining_balance

        self.save(update_fields=[
            'proforma_claimed_amount', 'invoice_claimed_amount',
            'remaining_proforma_balance', 'remaining_invoice_balance'
        ])

    def get_available_proforma_percentage(self):
        """Get available percentage for proforma invoice creation based on remaining balance"""
        from decimal import Decimal
        
        if self.subtotal <= 0:
            return Decimal('0')
        
        # If remaining balance is 0 but no proforma invoices exist, this is a new quotation - allow 100%
        if self.remaining_proforma_balance == 0 and self.proforma_invoices.count() == 0:
            return Decimal('100')
        
        # Calculate the percentage of remaining proforma balance
        return (self.remaining_proforma_balance / self.subtotal) * Decimal('100')

    def get_available_invoice_percentage(self):
        """Get available percentage for tax invoice creation based on remaining balance"""
        from decimal import Decimal
        
        if self.total_amount <= 0:
            return Decimal('0')
        
        # If remaining balance is 0 but no invoices exist, this is a new quotation - allow 100%
        if self.remaining_invoice_balance == 0 and self.invoices.count() == 0:
            return Decimal('100')
        
        # Calculate the percentage of remaining invoice balance
        return (self.remaining_invoice_balance / self.total_amount) * Decimal('100')

    @property
    def can_create_proforma(self):
        """Check if more proforma invoices can be created from this quotation"""
        return self.remaining_proforma_balance > 0

    @property
    def can_create_invoice(self):
        """Check if more invoices can be created from this quotation"""
        return self.remaining_invoice_balance > 0
    
    def reject_quotation(self, rejection_reason, rejected_by_user):
        """Reject this quotation and update related documents"""
        from django.utils import timezone
        
        # Mark as rejected
        self.is_rejected = True
        self.status = 'rejected'
        self.rejection_reason = rejection_reason
        self.rejected_by = rejected_by_user
        self.rejected_at = timezone.now()
        self.save()
    
    @property
    def can_be_rejected(self):
        """Check if this quotation can be rejected"""
        return not self.is_rejected and self.status not in ['converted'] and not self.po_created and not self.invoice_created and not self.proforma_created


class QuotationItem(models.Model):
    """Individual line items in a quotation"""

    quotation = models.ForeignKey(Quotation, on_delete=models.CASCADE, related_name='quotation_items')
    product = models.ForeignKey(Product, on_delete=models.CASCADE)

    # Item details (captured at time of quotation)
    product_name = models.CharField(max_length=255)
    product_code = models.CharField(max_length=50)
    description = models.TextField(blank=True)
    hsn_sac_code = models.CharField(max_length=20, blank=True)

    # Pricing and quantity
    quantity = models.DecimalField(max_digits=12, decimal_places=2)
    unit = models.CharField(max_length=10)
    unit_price = models.DecimalField(max_digits=12, decimal_places=2)
    line_total = models.DecimalField(max_digits=15, decimal_places=2)

    # Tax information
    gst_rate = models.DecimalField(max_digits=5, decimal_places=2)

    # Line item order
    line_number = models.PositiveIntegerField(default=1)

    class Meta:
        db_table = 'finance_quotation_items'
        ordering = ['line_number']
        unique_together = ['quotation', 'line_number']

    def __str__(self):
        return escape(f"{self.quotation.quotation_number} - {self.product_name}")

    def save(self, *args, **kwargs):
        # Extract skip_totals_calculation before passing to parent save
        skip_totals_calculation = kwargs.pop('skip_totals_calculation', False)

        # Capture product details at time of quotation
        if self.product:
            self.product_name = self.product.name
            self.product_code = self.product.product_code
            self.description = self.product.description
            self.unit = self.product.unit_ref.code if self.product.unit_ref else self.product.unit
            self.gst_rate = self.product.gst_rate

            # Get HSN/SAC code
            if self.product.hsn_code:
                self.hsn_sac_code = self.product.hsn_code.code
            elif self.product.sac_code:
                self.hsn_sac_code = self.product.sac_code.code

        # Calculate line total
        self.line_total = self.quantity * self.unit_price

        super().save(*args, **kwargs)

        # Recalculate quotation totals only if not in bulk creation
        if not skip_totals_calculation:
            self.quotation.calculate_totals()


class PurchaseOrder(models.Model):
    """Purchase Order/Work Order model created from quotations"""

    STATUS_CHOICES = [
        ('active', 'Active'),
        ('partially_completed', 'Partially Completed'),
        ('completed', 'Completed'),
    ]

    CLAIM_TYPE_CHOICES = [
        ('percentage', 'Percentage-based Claiming'),
        ('quantity', 'Quantity-based Claiming'),
    ]

    PROFORMA_STATUS_CHOICES = [
        ('not_started', 'Not Started'),
        ('partial', 'Partially Claimed'),
        ('completed', 'Fully Claimed'),
    ]

    INVOICE_STATUS_CHOICES = [
        ('not_started', 'Not Started'),
        ('partial', 'Partially Invoiced'),
        ('completed', 'Fully Invoiced'),
    ]

    GST_TYPE_CHOICES = [
        ('igst', 'IGST (Inter-State)'),
        ('cgst_sgst', 'CGST + SGST (Intra-State)'),
        ('exempt', 'GST Exempt'),
    ]

    # Basic Information
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='purchase_orders')
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='purchase_orders')
    quotation = models.ForeignKey(Quotation, on_delete=models.CASCADE, related_name='purchase_orders', null=True, blank=True, help_text="Original quotation this PO is based on (optional for direct POs)")

    # PO/WO Details
    po_number = models.CharField(max_length=100, help_text="Client's PO/WO number")
    po_date = models.DateField(help_text="Client's PO/WO date")
    po_file = models.FileField(upload_to='po_files/', null=True, blank=True, help_text="Client's PO/WO file attachment")

    # Internal tracking
    internal_po_number = models.CharField(max_length=50, db_index=True, help_text="Our internal PO number")

    # Quotation Details (copied from original quotation, optional for direct POs)
    quotation_date = models.DateField(null=True, blank=True)
    valid_until = models.DateField(null=True, blank=True)
    reference = models.CharField(max_length=100, blank=True, help_text="Customer reference or PO number")

    # Shipping Address (can be different from customer's default)
    shipping_address = models.ForeignKey(
        CustomerShippingAddress,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        help_text="Selected shipping address for this PO"
    )

    # GST Information (copied from quotation)
    gst_type = models.CharField(max_length=20, choices=GST_TYPE_CHOICES)
    customer_gstin = models.CharField(max_length=15, blank=True, help_text="Customer GSTIN at time of PO")
    company_gstin = models.CharField(max_length=15, blank=True, help_text="Company GSTIN at time of PO")

    # Financial Totals
    subtotal = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    total_tax = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    total_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)

    # Tax Breakdown (for CGST+SGST)
    cgst_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    sgst_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    igst_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)

    # Additional Charges
    discount_percentage = models.DecimalField(max_digits=5, decimal_places=2, default=0.00)
    discount_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    shipping_charges = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    other_charges = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)

    # Status and Notes
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft')
    notes = models.TextField(blank=True, help_text="Internal notes")
    terms_and_conditions = models.TextField(blank=True)

    # Advanced Workflow Fields
    claim_type = models.CharField(
        max_length=20,
        choices=CLAIM_TYPE_CHOICES,
        blank=True,
        null=True,
        help_text="How proforma invoices will be claimed from this PO (set on first invoice creation)"
    )

    # Balance Tracking Fields
    proforma_claimed_amount = models.DecimalField(
        max_digits=15,
        decimal_places=2,
        default=0.00,
        help_text="Total amount claimed through proforma invoices"
    )

    invoice_claimed_amount = models.DecimalField(
        max_digits=15,
        decimal_places=2,
        default=0.00,
        help_text="Total amount invoiced (final invoices with tax)"
    )

    remaining_proforma_balance = models.DecimalField(
        max_digits=15,
        decimal_places=2,
        default=0.00,
        help_text="Remaining amount available for proforma claiming"
    )

    remaining_invoice_balance = models.DecimalField(
        max_digits=15,
        decimal_places=2,
        default=0.00,
        help_text="Remaining amount to be invoiced (with tax)"
    )

    # Workflow Status Tracking
    proforma_status = models.CharField(
        max_length=20,
        choices=PROFORMA_STATUS_CHOICES,
        default='not_started',
        help_text="Status of proforma invoice claiming"
    )

    invoice_status = models.CharField(
        max_length=20,
        choices=INVOICE_STATUS_CHOICES,
        default='not_started',
        help_text="Status of final invoicing"
    )

    # Audit fields
    created_by = models.ForeignKey(CompanyServiceUser, on_delete=models.SET_NULL, null=True, related_name='created_purchase_orders')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'finance_purchase_orders'
        ordering = ['-created_at']
        unique_together = ['company', 'internal_po_number']
        constraints = [
            models.UniqueConstraint(
                fields=['company', 'po_number'],
                name='finance_po_company_po_number_uniq'
            ),
        ]
        indexes = [
            models.Index(fields=['company', 'po_number'], name='finance_po_company_po_idx'),
            models.Index(fields=['company', 'internal_po_number'], name='fin_po_int_idx'),
        ]

    def __str__(self):
        return escape(f"{self.internal_po_number} - {self.customer.name}")

    def save(self, *args, **kwargs):
        # Generate internal PO number if not provided
        if not self.internal_po_number:
            from django.db import transaction
            import time
            
            max_retries = 10
            for attempt in range(max_retries):
                try:
                    with transaction.atomic():
                        # First try the company's auto-code system
                        try:
                            from authentication.utils import generate_auto_code
                            generated_code = generate_auto_code(self.company.id, 'purchase_order')
                            
                            # Check if this generated code already exists
                            if not PurchaseOrder.objects.filter(
                                company=self.company,
                                internal_po_number=generated_code
                            ).exists():
                                self.internal_po_number = generated_code
                                break  # Success, exit retry loop
                        except Exception:
                            pass  # Fall through to manual generation
                        
                        # Fallback to manual generation
                        current_year = timezone.now().year
                        
                        # Get ALL existing PO numbers for this company (not just current year)
                        # to handle cases where company dashboard uses different format
                        existing_pos = PurchaseOrder.objects.filter(
                            company=self.company
                        ).values_list('internal_po_number', flat=True)
                        
                        # Try different number formats based on existing patterns
                        patterns_to_try = [
                            f'PO-{current_year % 100}-{{:03d}}',  # PO-25-001 format
                            f'PO-{current_year}-{{:06d}}',        # PO-2025-000001 format
                            f'PO-{{:06d}}',                       # PO-000001 format
                        ]
                        
                        generated = False
                        for pattern in patterns_to_try:
                            # Find the highest number for this pattern
                            max_number = 0
                            pattern_prefix = pattern.split('{')[0]  # Get prefix before number
                            
                            for existing_po in existing_pos:
                                if existing_po and existing_po.startswith(pattern_prefix):
                                    try:
                                        # Extract number from the end
                                        number_part = existing_po[len(pattern_prefix):]
                                        if number_part.isdigit():
                                            max_number = max(max_number, int(number_part))
                                    except (ValueError, IndexError):
                                        continue
                            
                            # Try the next number in sequence
                            next_number = max_number + 1
                            candidate = pattern.format(next_number)
                            
                            # Check if this candidate is unique
                            if candidate not in existing_pos:
                                self.internal_po_number = candidate
                                generated = True
                                break
                        
                        if generated:
                            break  # Success, exit retry loop
                        
                        # If all patterns failed, use timestamp-based fallback
                        timestamp = int(time.time() * 1000) % 1000000
                        self.internal_po_number = f"PO-{current_year}-T{timestamp:06d}"
                        break
                        
                except Exception as retry_error:
                    if 'unique constraint' in str(retry_error).lower() or 'duplicate' in str(retry_error).lower():
                        # If it's a uniqueness error, retry
                        if attempt < max_retries - 1:
                            continue
                        else:
                            # Last attempt failed, use timestamp-based code
                            timestamp = int(time.time() * 1000) % 1000000
                            self.internal_po_number = f"PO-FALLBACK-{timestamp:06d}"
                            break
                    else:
                        # Different error, re-raise
                        raise retry_error

        # Set GST information from customer and company if not from quotation
        if not self.quotation and self.customer:
            # Determine GST type based on customer and company GSTIN
            if self.customer.gstin and hasattr(self.company, 'gst_number') and self.company.gst_number:
                customer_state_code = self.customer.gstin[:2]
                company_state_code = self.company.gst_number[:2]

                if customer_state_code == company_state_code:
                    self.gst_type = 'cgst_sgst'  # Same state - CGST + SGST
                else:
                    self.gst_type = 'igst'  # Different state - IGST
            else:
                self.gst_type = 'exempt'  # No GST if either party doesn't have GSTIN

            # Store GSTIN values at time of PO creation
            self.customer_gstin = self.customer.gstin or ''
            self.company_gstin = getattr(self.company, 'gst_number', '') or ''

        # Initialize balance tracking for new POs before saving
        is_new = self.pk is None
        if is_new:
            from decimal import Decimal
            self.proforma_claimed_amount = Decimal('0')
            self.invoice_claimed_amount = Decimal('0')
            self.proforma_status = 'not_started'
            self.invoice_status = 'not_started'
            # Initialize remaining balances to 0 - they will be set properly after calculate_totals()
            self.remaining_proforma_balance = Decimal('0')
            self.remaining_invoice_balance = Decimal('0')
            # Set default status to active for new POs
            if not hasattr(self, 'status') or not self.status:
                self.status = 'active'

        super().save(*args, **kwargs)

    def calculate_totals(self):
        """Calculate all totals for this PO"""
        from decimal import Decimal

        items = self.po_items.all()

        # Calculate subtotal
        subtotal = sum(item.line_total for item in items)

        # Apply discount
        if self.discount_percentage > 0:
            self.discount_amount = (subtotal * self.discount_percentage) / Decimal('100')

        subtotal_after_discount = subtotal - self.discount_amount

        # Add other charges (ensure all values are Decimal)
        shipping_charges = Decimal(str(self.shipping_charges)) if self.shipping_charges else Decimal('0')
        other_charges = Decimal(str(self.other_charges)) if self.other_charges else Decimal('0')
        subtotal_with_charges = subtotal_after_discount + shipping_charges + other_charges

        self.subtotal = subtotal_with_charges

        # Calculate tax
        total_tax = Decimal('0')
        self.cgst_amount = Decimal('0')
        self.sgst_amount = Decimal('0')
        self.igst_amount = Decimal('0')

        if self.gst_type == 'cgst_sgst':
            # CGST + SGST (each is half of total GST rate)
            for item in items:
                item_tax = (item.line_total * item.gst_rate) / Decimal('100')
                total_tax += item_tax
                self.cgst_amount += item_tax / Decimal('2')
                self.sgst_amount += item_tax / Decimal('2')
        elif self.gst_type == 'igst':
            # IGST (full GST rate)
            for item in items:
                item_tax = (item.line_total * item.gst_rate) / Decimal('100')
                total_tax += item_tax
                self.igst_amount += item_tax

        self.total_tax = total_tax

        # Calculate final total
        self.total_amount = self.subtotal + self.total_tax

        # Initialize remaining balances for new POs or fix existing ones
        if self.remaining_proforma_balance == 0 and self.remaining_invoice_balance == 0 and self.subtotal > 0:
            self.remaining_proforma_balance = self.subtotal
            self.remaining_invoice_balance = self.total_amount

        self.save(update_fields=[
            'subtotal', 'total_tax', 'total_amount', 'discount_amount',
            'cgst_amount', 'sgst_amount', 'igst_amount',
            'remaining_proforma_balance', 'remaining_invoice_balance'
        ])

    def update_balance_tracking(self):
        """World-Class Sophisticated Balance Tracking - Cross-impact between proforma and tax invoices"""
        from decimal import Decimal

        # Calculate total proforma claimed amount (subtotal only) - EXCLUDE rejected proformas
        proforma_subtotal_total = sum(
            proforma.subtotal for proforma in self.proforma_invoices.filter(is_rejected=False)
        ) or Decimal('0')

        # Calculate total tax invoice claimed amount (with tax) - EXCLUDE rejected invoices
        invoice_total = sum(
            invoice.total_amount for invoice in self.invoices.filter(is_rejected=False)
        ) or Decimal('0')

        # Calculate tax invoice subtotal impact (for cross-impact calculation) - EXCLUDE rejected invoices
        invoice_subtotal_total = sum(
            invoice.subtotal for invoice in self.invoices.filter(is_rejected=False)
        ) or Decimal('0')

        # Update claimed amounts
        self.proforma_claimed_amount = proforma_subtotal_total
        self.invoice_claimed_amount = invoice_total

        # SOPHISTICATED LOGIC: Tax invoice claiming reduces proforma claimable base
        # Original subtotal: ₹800
        # Tax invoice claimed subtotal: ₹200 (from 25% tax invoice)
        # New proforma base: ₹800 - ₹200 = ₹600
        # Remaining proforma claimable: ₹600 - already claimed proforma subtotal

        reduced_proforma_base = self.subtotal - invoice_subtotal_total
        remaining_proforma = max(Decimal('0'), reduced_proforma_base - proforma_subtotal_total)
        
        # Handle rounding precision - if remaining is very small (< ₹5), consider it completed
        if remaining_proforma < Decimal('5.00'):
            self.remaining_proforma_balance = Decimal('0.00')
        else:
            self.remaining_proforma_balance = remaining_proforma

        # For tax invoice: remaining from total amount (with tax) minus what's already invoiced
        remaining_balance = self.total_amount - invoice_total
        
        # Handle rounding precision - if remaining is very small (< ₹5), consider it completed
        if remaining_balance < Decimal('5.00'):
            self.remaining_invoice_balance = Decimal('0.00')
        else:
            self.remaining_invoice_balance = remaining_balance

        # Update status based on balances
        if proforma_subtotal_total == 0:
            self.proforma_status = 'not_started'
        elif self.remaining_proforma_balance <= 0 or reduced_proforma_base <= 0:
            self.proforma_status = 'completed'
        else:
            self.proforma_status = 'partial'

        # PO completion is based ONLY on tax invoices (not proforma)
        if invoice_total == 0:
            self.invoice_status = 'not_started'
            # PO status logic: active = can raise proforma invoices
            self.status = 'active'
        elif self.remaining_invoice_balance <= 0:
            self.invoice_status = 'completed'
            # PO status logic: completed = all invoices raised
            self.status = 'completed'
        else:
            self.invoice_status = 'partial'
            # PO status logic: partially_completed = can raise tax invoices
            self.status = 'partially_completed'

        self.save(update_fields=[
            'proforma_claimed_amount', 'invoice_claimed_amount',
            'remaining_proforma_balance', 'remaining_invoice_balance',
            'proforma_status', 'invoice_status', 'status'
        ])

    def get_world_class_payment_summary(self):
        """World-Class Payment Summary - Complete payment tracking for PO"""
        from decimal import Decimal

        # Calculate proforma payments (advances)
        proforma_payments = sum(
            pf.paid_amount for pf in self.proforma_invoices.all()
        ) or Decimal('0')

        # Calculate invoice payments (direct)
        invoice_payments = sum(
            inv.paid_amount for inv in self.invoices.all()
        ) or Decimal('0')

        # Calculate outstanding amounts
        proforma_outstanding = sum(
            pf.outstanding_amount for pf in self.proforma_invoices.all()
        ) or Decimal('0')

        invoice_outstanding = sum(
            inv.outstanding_amount for inv in self.invoices.all()
        ) or Decimal('0')

        total_paid = proforma_payments + invoice_payments
        total_outstanding = proforma_outstanding + invoice_outstanding

        return {
            'po_total_amount': self.total_amount,
            'proforma_payments': proforma_payments,
            'invoice_payments': invoice_payments,
            'total_paid': total_paid,
            'proforma_outstanding': proforma_outstanding,
            'invoice_outstanding': invoice_outstanding,
            'total_outstanding': total_outstanding,
            'payment_completion_percentage': float((total_paid / self.total_amount) * 100) if self.total_amount > 0 else 0
        }

    def get_sophisticated_claiming_status(self):
        """World-Class Sophisticated Claiming Status - Shows cross-impact calculations"""
        from decimal import Decimal

        # Calculate current claimed amounts
        proforma_subtotal_claimed = sum(
            pf.subtotal for pf in self.proforma_invoices.all()
        ) or Decimal('0')

        invoice_total_claimed = sum(
            inv.total_amount for inv in self.invoices.all()
        ) or Decimal('0')

        invoice_subtotal_claimed = sum(
            inv.subtotal for inv in self.invoices.all()
        ) or Decimal('0')

        # Calculate percentages
        proforma_claimed_percentage = float((proforma_subtotal_claimed / self.subtotal) * 100) if self.subtotal > 0 else 0
        invoice_claimed_percentage = float((invoice_total_claimed / self.total_amount) * 100) if self.total_amount > 0 else 0

        # Calculate reduced proforma base due to tax invoice impact
        reduced_proforma_base = self.subtotal - invoice_subtotal_claimed
        available_proforma_percentage = float((self.remaining_proforma_balance / self.subtotal) * 100) if self.subtotal > 0 else 0

        return {
            'original_po_amount': self.total_amount,
            'original_subtotal': self.subtotal,
            'original_tax': self.total_tax,

            # Proforma claiming status
            'proforma_claimed_amount': proforma_subtotal_claimed,
            'proforma_claimed_percentage': proforma_claimed_percentage,
            'proforma_base_reduced_by_tax_invoices': invoice_subtotal_claimed,
            'current_proforma_base': reduced_proforma_base,
            'available_proforma_amount': self.remaining_proforma_balance,
            'available_proforma_percentage': available_proforma_percentage,

            # Tax invoice claiming status
            'tax_invoice_claimed_amount': invoice_total_claimed,
            'tax_invoice_claimed_percentage': invoice_claimed_percentage,
            'available_tax_invoice_amount': self.remaining_invoice_balance,
            'available_tax_invoice_percentage': float((self.remaining_invoice_balance / self.total_amount) * 100) if self.total_amount > 0 else 0,

            # Overall status
            'po_completion_percentage': invoice_claimed_percentage,  # Only tax invoices determine completion
            'is_po_completed': self.invoice_status == 'completed',
            'total_invoices_created': self.proforma_invoices.count() + self.invoices.count()
        }

    def fix_balance_tracking(self):
        """Fix balance tracking for POs that have incorrect balances"""
        from decimal import Decimal

        # Fix if balances are zero but PO has amounts (common for new POs)
        if (self.remaining_proforma_balance == 0 and self.remaining_invoice_balance == 0 and
            self.subtotal > 0 and self.total_amount > 0):
            
            # Check if there are actually no invoices created yet
            existing_proformas = self.proforma_invoices.count()
            existing_invoices = self.invoices.count()
            
            if existing_proformas == 0 and existing_invoices == 0:
                # This is a new PO with no invoices, set full balances
                self.remaining_proforma_balance = self.subtotal
                self.remaining_invoice_balance = self.total_amount
                self.proforma_claimed_amount = Decimal('0')
                self.invoice_claimed_amount = Decimal('0')
                self.proforma_status = 'not_started'
                self.invoice_status = 'not_started'
                self.save(update_fields=[
                    'remaining_proforma_balance', 'remaining_invoice_balance',
                    'proforma_claimed_amount', 'invoice_claimed_amount',
                    'proforma_status', 'invoice_status'
                ])
                return True
            else:
                # There are existing invoices, recalculate properly
                self.update_balance_tracking()
                return True
        
        # Also fix if PO has zero totals but items exist (recalculate totals)
        if self.subtotal == 0 and self.total_amount == 0 and self.po_items.exists():
            self.calculate_totals()
            return True
            
        return False

    @property
    def can_create_proforma(self):
        """Check if more proforma invoices can be created"""
        return self.remaining_proforma_balance > 0

    @property
    def can_create_invoice(self):
        """Check if more invoices can be created"""
        return self.remaining_invoice_balance > 0

    @property
    def proforma_completion_percentage(self):
        """Get proforma claiming completion percentage"""
        if self.subtotal == 0:
            return 0
        return float((self.proforma_claimed_amount / self.subtotal) * 100)

    @property
    def invoice_completion_percentage(self):
        """Get invoice completion percentage"""
        if self.total_amount == 0:
            return 0
        return float((self.invoice_claimed_amount / self.total_amount) * 100)

    def get_available_proforma_percentage(self):
        """Get available percentage for proforma invoice creation based on remaining balance"""
        from decimal import Decimal
        
        if self.subtotal <= 0:
            return Decimal('0')
        
        # If remaining balance is 0 but no proforma invoices exist, this is a new PO - allow 100%
        if self.remaining_proforma_balance == 0 and self.proforma_invoices.count() == 0:
            return Decimal('100')
        
        # Calculate the percentage of remaining proforma balance
        return (self.remaining_proforma_balance / self.subtotal) * Decimal('100')

    def get_available_invoice_percentage(self):
        """Get available percentage for tax invoice creation based on remaining balance"""
        from decimal import Decimal
        
        if self.total_amount <= 0:
            return Decimal('0')
        
        # If remaining balance is 0 but no NON-REJECTED invoices exist, this is a new PO - allow 100%
        if self.remaining_invoice_balance == 0 and self.invoices.filter(is_rejected=False).count() == 0:
            return Decimal('100')
        
        # Calculate the percentage of remaining invoice balance
        return (self.remaining_invoice_balance / self.total_amount) * Decimal('100')


class PurchaseOrderItem(models.Model):
    """Individual items in a Purchase Order"""

    purchase_order = models.ForeignKey(PurchaseOrder, on_delete=models.CASCADE, related_name='po_items')
    product = models.ForeignKey(Product, on_delete=models.CASCADE)

    # Item details (captured at time of PO creation)
    product_name = models.CharField(max_length=255)
    product_code = models.CharField(max_length=50)
    description = models.TextField(blank=True)
    hsn_sac_code = models.CharField(max_length=20, blank=True)

    # Pricing and quantity
    quantity = models.DecimalField(max_digits=12, decimal_places=2)
    unit = models.CharField(max_length=10)
    unit_price = models.DecimalField(max_digits=12, decimal_places=2)
    line_total = models.DecimalField(max_digits=15, decimal_places=2)

    # Tax information
    gst_rate = models.DecimalField(max_digits=5, decimal_places=2)

    # Quantity-based Claiming Tracking
    proforma_claimed_quantity = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=0.00,
        help_text="Quantity claimed through proforma invoices"
    )

    invoice_claimed_quantity = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=0.00,
        help_text="Quantity invoiced through final invoices"
    )

    # Line item order
    line_number = models.PositiveIntegerField(default=1)

    class Meta:
        db_table = 'finance_purchase_order_items'
        ordering = ['line_number']
        unique_together = ['purchase_order', 'line_number']

    def __str__(self):
        return escape(f"{self.purchase_order.internal_po_number} - {self.product_name}")

    def save(self, *args, **kwargs):
        # Extract skip_totals_calculation before passing to parent save
        skip_totals_calculation = kwargs.pop('skip_totals_calculation', False)

        # Capture product details at time of PO creation
        if self.product:
            self.product_name = self.product.name
            self.product_code = self.product.product_code
            self.description = self.product.description
            self.unit = self.product.unit_ref.code if self.product.unit_ref else self.product.unit
            self.gst_rate = self.product.gst_rate

            # Get HSN/SAC code
            if self.product.hsn_code:
                self.hsn_sac_code = self.product.hsn_code.code
            elif self.product.sac_code:
                self.hsn_sac_code = self.product.sac_code.code

        # Calculate line total
        self.line_total = self.quantity * self.unit_price

        super().save(*args, **kwargs)

        # Recalculate PO totals only if not in bulk creation
        if not skip_totals_calculation:
            self.purchase_order.calculate_totals()

    @property
    def remaining_proforma_quantity(self):
        """Get remaining quantity available for proforma claiming"""
        return self.quantity - self.proforma_claimed_quantity

    @property
    def remaining_invoice_quantity(self):
        """Get remaining quantity available for final invoicing"""
        return self.quantity - self.invoice_claimed_quantity

    @property
    def proforma_quantity_percentage(self):
        """Get percentage of quantity claimed through proforma"""
        if self.quantity == 0:
            return 0
        return float((self.proforma_claimed_quantity / self.quantity) * 100)

    @property
    def invoice_quantity_percentage(self):
        """Get percentage of quantity invoiced"""
        if self.quantity == 0:
            return 0
        return float((self.invoice_claimed_quantity / self.quantity) * 100)


class ProformaInvoice(models.Model):
    """Proforma Invoice model - created from approved Purchase Orders"""

    PAYMENT_STATUS_CHOICES = [
        ('unpaid', 'Unpaid'),
        ('partially_paid', 'Partially Paid'),
        ('paid', 'Fully Paid'),
        ('overdue', 'Overdue'),
    ]

    # Basic Information
    company = models.ForeignKey(Company, on_delete=models.CASCADE)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    purchase_order = models.ForeignKey(PurchaseOrder, on_delete=models.CASCADE, related_name='proforma_invoices', null=True, blank=True)
    quotation = models.ForeignKey(Quotation, on_delete=models.CASCADE, related_name='proforma_invoices', null=True, blank=True, help_text="Quotation this proforma is created from (if not from PO)")

    # Proforma Invoice Details
    proforma_number = models.CharField(max_length=50, db_index=True)
    proforma_date = models.DateField()
    due_date = models.DateField()
    reference = models.CharField(max_length=100, blank=True)

    # Customer and Shipping Information
    customer_gstin = models.CharField(max_length=15, blank=True)
    company_gstin = models.CharField(max_length=15, blank=True)
    shipping_address = models.ForeignKey(CustomerShippingAddress, on_delete=models.SET_NULL, null=True, blank=True)

    # GST Information
    gst_type = models.CharField(max_length=10, choices=[
        ('igst', 'IGST'),
        ('cgst_sgst', 'CGST + SGST'),
        ('exempt', 'GST Exempt')
    ], default='igst')

    # Financial Information
    subtotal = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    total_tax = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    total_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)

    # Tax Breakdown
    cgst_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    sgst_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    igst_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)

    # Additional Charges
    discount_percentage = models.DecimalField(max_digits=5, decimal_places=2, default=0.00)
    discount_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    shipping_charges = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    other_charges = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)

    # Notes
    notes = models.TextField(blank=True)
    terms_and_conditions = models.TextField(blank=True)

    # Claim Tracking Fields
    claim_type = models.CharField(
        max_length=20,
        choices=[
            ('percentage', 'Percentage-based'),
            ('quantity', 'Quantity-based'),
        ],
        help_text="Type of claim from PO"
    )

    claim_percentage = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
        blank=True,
        help_text="Percentage of PO claimed (for percentage-based)"
    )

    is_advance_bill = models.BooleanField(
        default=True,
        help_text="True for proforma (advance bill without tax), False for final invoice"
    )

    # World-Class Payment Tracking Fields
    payment_status = models.CharField(
        max_length=20,
        choices=PAYMENT_STATUS_CHOICES,
        default='unpaid',
        help_text="Payment status of this proforma invoice"
    )

    paid_amount = models.DecimalField(
        max_digits=15,
        decimal_places=2,
        default=0.00,
        help_text="Total amount paid against this proforma invoice"
    )

    outstanding_amount = models.DecimalField(
        max_digits=15,
        decimal_places=2,
        default=0.00,
        help_text="Outstanding amount for this proforma invoice"
    )

    last_payment_date = models.DateField(
        null=True,
        blank=True,
        help_text="Date of last payment received"
    )
    
    # Indian Compliance Fields
    gst_transaction_id = models.CharField(max_length=50, blank=True, help_text="Unique GST transaction ID")
    place_of_supply = models.CharField(max_length=2, blank=True, help_text="State code where supply is made")

    # Revision tracking fields
    is_revised = models.BooleanField(default=False, help_text="Whether this proforma invoice has been revised")
    revision_count = models.PositiveIntegerField(default=0, help_text="Number of times this proforma invoice has been revised")
    revised_at = models.DateTimeField(null=True, blank=True, help_text="When this proforma invoice was last revised")
    revised_by = models.ForeignKey(CompanyServiceUser, on_delete=models.SET_NULL, null=True, blank=True, related_name='revised_proforma_invoices')
    
    # Rejection tracking fields
    is_rejected = models.BooleanField(default=False, help_text="Whether this proforma invoice has been rejected")
    rejection_reason = models.TextField(blank=True, null=True, help_text="Reason for rejection")
    rejected_by = models.ForeignKey(CompanyServiceUser, on_delete=models.SET_NULL, null=True, blank=True, related_name='rejected_proforma_invoices')
    rejected_at = models.DateTimeField(null=True, blank=True, help_text="When this proforma invoice was rejected")
    
    # Audit fields
    created_by = models.ForeignKey(CompanyServiceUser, on_delete=models.SET_NULL, null=True, related_name='created_proforma_invoices')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'finance_proforma_invoices'
        ordering = ['-created_at']
        unique_together = ['company', 'proforma_number']
        indexes = [
            models.Index(fields=['company', 'proforma_number'], name='finance_pi_company_no_idx'),
        ]

    def __str__(self):
        return escape(f"{self.proforma_number} - {self.customer.name}")

    def save(self, *args, **kwargs):
        # Generate proforma number if not provided
        if not self.proforma_number:
            try:
                from authentication.utils import generate_auto_code
                self.proforma_number = generate_auto_code(self.company.id, 'proforma_invoice')
            except Exception as e:
                # Fallback to old system if auto-code fails
                latest_proforma = ProformaInvoice.objects.filter(
                    company=self.company
                ).order_by('-created_at').first()

                if latest_proforma and latest_proforma.proforma_number:
                    # Extract number from format PI-2025-000001
                    try:
                        parts = latest_proforma.proforma_number.split('-')
                        if len(parts) == 3 and parts[0] == 'PI':
                            year = parts[1]
                            number = int(parts[2])
                            current_year = timezone.now().year

                            if int(year) == current_year:
                                new_number = number + 1
                            else:
                                new_number = 1

                            self.proforma_number = f"PI-{current_year}-{new_number:06d}"
                        else:
                            self.proforma_number = f"PI-{timezone.now().year}-000001"
                    except (ValueError, IndexError):
                        self.proforma_number = f"PI-{timezone.now().year}-000001"
                else:
                    self.proforma_number = f"PI-{timezone.now().year}-000001"

        # Automatically set payment status when creating proforma invoice
        if self.pk is None:  # New proforma invoice
            self.payment_status = 'unpaid'
            self.outstanding_amount = self.total_amount or Decimal('0')
            self.paid_amount = Decimal('0')

        super().save(*args, **kwargs)

        # Update PO balance tracking after save
        if self.purchase_order:
            # Auto-set PO to active when first proforma invoice is created
            if self.purchase_order.status not in ['partially_completed', 'completed']:
                self.purchase_order.status = 'active'
                self.purchase_order.save(update_fields=['status'])
            self.purchase_order.update_balance_tracking()
        
        # Update quotation balance tracking after save
        if self.quotation:
            self.quotation.update_balance_tracking()

    def calculate_totals(self):
        """Calculate all totals for this proforma invoice - NO TAX for proforma invoices"""
        from decimal import Decimal

        # Calculate subtotal from items
        subtotal = sum(item.line_total for item in self.proforma_items.all()) or Decimal('0')

        # Apply discount
        if self.discount_percentage > 0:
            discount_amount = subtotal * (self.discount_percentage / Decimal('100'))
        else:
            # Ensure discount_amount is Decimal
            discount_amount = Decimal(str(self.discount_amount)) if self.discount_amount else Decimal('0')

        subtotal_after_discount = subtotal - discount_amount

        # PROFORMA INVOICES DO NOT INCLUDE TAX - Set all tax amounts to zero
        total_tax = Decimal('0')
        cgst_amount = Decimal('0')
        sgst_amount = Decimal('0')
        igst_amount = Decimal('0')

        # Calculate final total (ensure all values are Decimal) - NO TAX ADDED
        shipping_charges = Decimal(str(self.shipping_charges)) if self.shipping_charges else Decimal('0')
        other_charges = Decimal(str(self.other_charges)) if self.other_charges else Decimal('0')
        total_with_charges = subtotal_after_discount + shipping_charges + other_charges
        total_amount = total_with_charges  # NO TAX ADDED FOR PROFORMA

        # Update fields
        self.subtotal = subtotal_after_discount
        self.discount_amount = discount_amount
        self.total_tax = total_tax  # Always zero for proforma
        self.cgst_amount = cgst_amount  # Always zero for proforma
        self.sgst_amount = sgst_amount  # Always zero for proforma
        self.igst_amount = igst_amount  # Always zero for proforma
        self.total_amount = total_amount  # Base amount only, no tax

        # Save without triggering calculate_totals again
        super().save(update_fields=[
            'subtotal', 'total_tax', 'total_amount', 'discount_amount',
            'cgst_amount', 'sgst_amount', 'igst_amount'
        ])
    
    def reject_proforma(self, rejection_reason, rejected_by_user):
        """Reject this proforma invoice and update related documents"""
        from django.utils import timezone
        
        # Mark as rejected
        self.is_rejected = True
        self.rejection_reason = rejection_reason
        self.rejected_by = rejected_by_user
        self.rejected_at = timezone.now()
        self.save()
        
        # Update related PO balance tracking (remove this proforma's impact)
        if self.purchase_order:
            self.purchase_order.update_balance_tracking()
        
        # Update related quotation balance tracking (remove this proforma's impact)
        if self.quotation:
            self.quotation.update_balance_tracking()
    
    @property
    def can_be_rejected(self):
        """Check if this proforma invoice can be rejected"""
        return not self.is_rejected and self.payment_status not in ['paid']

    @property
    def customer_details(self):
        """Get customer details in dictionary format for PDF generation"""
        return {
            'name': self.customer.name,
            'address': self.customer.billing_address_line1,
            'city': self.customer.billing_city,
            'state': self.customer.billing_state,
            'pincode': self.customer.billing_pincode,
            'phone': self.customer.phone,
            'email': self.customer.email,
            'gst_number': self.customer.gstin,
        }


class ProformaInvoiceItem(models.Model):
    """Individual items in a Proforma Invoice"""

    proforma_invoice = models.ForeignKey(ProformaInvoice, on_delete=models.CASCADE, related_name='proforma_items')
    product = models.ForeignKey(Product, on_delete=models.CASCADE)

    # Item details (captured at time of proforma creation)
    product_name = models.CharField(max_length=255)
    product_code = models.CharField(max_length=50)
    description = models.TextField(blank=True)
    hsn_sac_code = models.CharField(max_length=20, blank=True)

    # Pricing and quantity
    quantity = models.DecimalField(max_digits=12, decimal_places=2)
    unit = models.CharField(max_length=10)
    unit_price = models.DecimalField(max_digits=12, decimal_places=2)
    line_total = models.DecimalField(max_digits=15, decimal_places=2)

    # Tax information
    gst_rate = models.DecimalField(max_digits=5, decimal_places=2)

    # Line item order
    line_number = models.PositiveIntegerField(default=1)

    class Meta:
        db_table = 'finance_proforma_invoice_items'
        ordering = ['line_number']
        unique_together = ['proforma_invoice', 'line_number']

    def __str__(self):
        return escape(f"{self.proforma_invoice.proforma_number} - {self.product_name}")

    @property
    def rate(self):
        """Alias for unit_price to match PDF generator expectations"""
        return self.unit_price

    @property
    def amount(self):
        """Calculate amount before tax (quantity * unit_price)"""
        return self.quantity * self.unit_price

    @property
    def tax_amount(self):
        """Calculate tax amount"""
        from decimal import Decimal
        amount = self.quantity * self.unit_price
        return amount * (self.gst_rate / Decimal('100'))

    def save(self, *args, **kwargs):
        # Extract skip_totals_calculation before passing to parent save
        skip_totals_calculation = kwargs.pop('skip_totals_calculation', False)

        # Capture product details at time of proforma creation
        if self.product:
            self.product_name = self.product.name
            self.product_code = self.product.product_code
            self.description = self.product.description
            self.unit = self.product.unit_ref.code if self.product.unit_ref else self.product.unit
            self.gst_rate = self.product.gst_rate

            # Get HSN/SAC code
            if self.product.hsn_code:
                self.hsn_sac_code = self.product.hsn_code.code
            elif self.product.sac_code:
                self.hsn_sac_code = self.product.sac_code.code

        # Calculate line total
        self.line_total = self.quantity * self.unit_price

        super().save(*args, **kwargs)

        # Recalculate proforma totals only if not in bulk creation
        if not skip_totals_calculation:
            self.proforma_invoice.calculate_totals()


class Invoice(models.Model):
    """World-Class Tax Invoice - Official invoice with tax, can be created simultaneously with Proforma"""

    PAYMENT_STATUS_CHOICES = [
        ('unpaid', 'Unpaid'),
        ('partially_paid', 'Partially Paid'),
        ('paid', 'Paid'),
        ('overdue', 'Overdue'),
    ]

    # Basic Information
    company = models.ForeignKey(Company, on_delete=models.CASCADE)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    purchase_order = models.ForeignKey(PurchaseOrder, on_delete=models.CASCADE, related_name='invoices', null=True, blank=True)
    proforma_invoice = models.ForeignKey(ProformaInvoice, on_delete=models.CASCADE, related_name='invoices', null=True, blank=True)
    quotation = models.ForeignKey(Quotation, on_delete=models.CASCADE, related_name='invoices', null=True, blank=True, help_text="Quotation this invoice is created from (if not from PO)")

    # Invoice Details
    invoice_number = models.CharField(max_length=50, db_index=True)
    invoice_date = models.DateField()
    due_date = models.DateField(null=True, blank=True)
    reference = models.CharField(max_length=100, blank=True)

    # Customer and Shipping Information
    customer_gstin = models.CharField(max_length=15, blank=True)
    company_gstin = models.CharField(max_length=15, blank=True)
    shipping_address = models.ForeignKey(CustomerShippingAddress, on_delete=models.SET_NULL, null=True, blank=True)

    # GST Information
    gst_type = models.CharField(max_length=10, choices=[
        ('igst', 'IGST'),
        ('cgst_sgst', 'CGST + SGST'),
        ('exempt', 'GST Exempt')
    ], default='igst')

    # Financial Information
    subtotal = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    total_tax = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    total_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)

    # Tax Breakdown
    cgst_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    sgst_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    igst_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)

    # Additional Charges
    discount_percentage = models.DecimalField(max_digits=5, decimal_places=2, default=0.00)
    discount_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    shipping_charges = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    other_charges = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)

    # World-Class Payment Information
    payment_status = models.CharField(max_length=20, choices=PAYMENT_STATUS_CHOICES, default='unpaid')
    paid_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    outstanding_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    last_payment_date = models.DateField(null=True, blank=True, help_text="Date of last payment received")
    payment_due_date = models.DateField(null=True, blank=True, help_text="Payment due date")

    # Advanced Invoice Tracking
    invoice_type = models.CharField(
        max_length=20,
        choices=[
            ('tax_invoice', 'Tax Invoice'),
            ('proforma', 'Proforma Invoice'),
            ('credit_note', 'Credit Note'),
            ('debit_note', 'Debit Note'),
        ],
        default='tax_invoice',
        help_text="Type of invoice"
    )

    # GST Payment Tracking
    GST_PAYMENT_STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('paid', 'Paid'),
        ('not_applicable', 'Not Applicable'),
    ]
    gst_payment_status = models.CharField(
        max_length=20, choices=GST_PAYMENT_STATUS_CHOICES, default='pending',
        help_text="Whether GST collected on this invoice has been remitted to government"
    )
    gst_paid_date = models.DateField(null=True, blank=True, help_text="Date GST was remitted to government")
    gst_payment_reference = models.CharField(max_length=100, blank=True, help_text="Challan/reference number for GST payment")

    # Notes
    notes = models.TextField(blank=True)
    terms_and_conditions = models.TextField(blank=True)

    # Indian Compliance Fields
    gst_transaction_id = models.CharField(max_length=50, blank=True, help_text="Unique GST transaction ID")
    is_filed_in_gstr1 = models.BooleanField(default=False)
    gstr1_filing_date = models.DateField(null=True, blank=True)
    place_of_supply = models.CharField(max_length=2, blank=True, help_text="State code where supply is made")
    reverse_charge_applicable = models.BooleanField(default=False)
    
    # Revision tracking fields
    is_revised = models.BooleanField(default=False, help_text="Whether this invoice has been revised")
    revision_count = models.PositiveIntegerField(default=0, help_text="Number of times this invoice has been revised")
    revised_at = models.DateTimeField(null=True, blank=True, help_text="When this invoice was last revised")
    revised_by = models.ForeignKey(CompanyServiceUser, on_delete=models.SET_NULL, null=True, blank=True, related_name='revised_invoices')
    
    # Rejection tracking fields
    is_rejected = models.BooleanField(default=False, help_text="Whether this invoice has been rejected")
    rejection_reason = models.TextField(blank=True, null=True, help_text="Reason for rejection")
    is_work_completed = models.BooleanField(default=False, help_text="Whether the work/service for this invoice has been completed")
    rejected_by = models.ForeignKey(CompanyServiceUser, on_delete=models.SET_NULL, null=True, blank=True, related_name='rejected_invoices')
    rejected_at = models.DateTimeField(null=True, blank=True, help_text="When this invoice was rejected")

    # Invoice-level TDS Configuration (one-time declaration, editable)
    tds_applicable = models.BooleanField(default=False, help_text="Whether TDS applies to payments on this invoice")
    tds_section = models.CharField(max_length=20, blank=True, help_text="TDS section code (194C, 194J, etc.)")
    tds_rate = models.DecimalField(max_digits=5, decimal_places=2, default=0.00, help_text="TDS rate percentage")

    # Claim tracking (for invoices from PO/Quotation)
    claim_percentage = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True, help_text="Percentage claimed from PO/Quotation")
    claim_method = models.CharField(max_length=20, blank=True, default='percentage', choices=[('percentage', 'Percentage'), ('as_per_unit', 'As Per Unit')], help_text="How the claim was made")

    # Audit fields
    created_by = models.ForeignKey(CompanyServiceUser, on_delete=models.SET_NULL, null=True, related_name='created_invoices')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'finance_invoices'
        ordering = ['-created_at']
        unique_together = ['company', 'invoice_number']
        indexes = [
            models.Index(fields=['invoice_number']),
            models.Index(fields=['company', 'invoice_number'], name='finance_inv_company_no_idx'),
            models.Index(fields=['company', 'invoice_date']),
            models.Index(fields=['customer', 'payment_status']),
            models.Index(fields=['created_at']),
        ]

    def __str__(self):
        return escape(f"{self.invoice_number} - {self.customer.name}")

    def save(self, *args, **kwargs):
        update_fields = kwargs.get('update_fields')

        # Generate invoice number if not provided
        if not self.invoice_number:
            try:
                from authentication.utils import generate_auto_code
                self.invoice_number = generate_auto_code(self.company.id, 'invoice')
            except Exception as e:
                # Fallback to old system if auto-code fails
                latest_invoice = Invoice.objects.filter(
                    company=self.company
                ).order_by('-created_at').first()

                if latest_invoice and latest_invoice.invoice_number:
                    # Extract number from format INV-2025-000001
                    try:
                        parts = latest_invoice.invoice_number.split('-')
                        if len(parts) == 3 and parts[0] == 'INV':
                            year = parts[1]
                            number = int(parts[2])
                            current_year = timezone.now().year

                            if int(year) == current_year:
                                new_number = number + 1
                            else:
                                new_number = 1

                            self.invoice_number = f"INV-{current_year}-{new_number:06d}"
                        else:
                            self.invoice_number = f"INV-{timezone.now().year}-000001"
                    except (ValueError, IndexError):
                        self.invoice_number = f"INV-{timezone.now().year}-000001"
                else:
                    self.invoice_number = f"INV-{timezone.now().year}-000001"

        # Skip recalculation when called with update_fields (targeted saves from payment status updates)
        if not update_fields:
            # Calculate outstanding amount
            from decimal import Decimal
            # Ensure both values are Decimal
            total_amount = Decimal(str(self.total_amount)) if self.total_amount is not None else Decimal('0')
            paid_amount = Decimal(str(self.paid_amount)) if self.paid_amount is not None else Decimal('0')
            self.outstanding_amount = total_amount - paid_amount

            # Update payment status based on amounts
            if self.paid_amount == 0:
                self.payment_status = 'unpaid'
            elif self.paid_amount >= self.total_amount:
                self.payment_status = 'paid'
            else:
                self.payment_status = 'partially_paid'

            # Check if overdue (only if due_date is set)
            if self.payment_status != 'paid' and self.due_date and self.due_date < timezone.now().date():
                self.payment_status = 'overdue'

        # Automatically set status to active when creating invoice
        if self.pk is None:  # New invoice
            pass  # No status field anymore

        super().save(*args, **kwargs)

        # Update PO balance tracking after save
        if self.purchase_order:
            # Auto-set PO to active when first invoice is created
            if self.purchase_order.status not in ['partially_completed', 'completed']:
                self.purchase_order.status = 'active'
                self.purchase_order.save(update_fields=['status'])
            self.purchase_order.update_balance_tracking()
            
            # Update PO status based on completion
            self._update_po_status_based_on_completion()
        
        # Update quotation balance tracking after save
        if self.quotation:
            self.quotation.update_balance_tracking()

    def calculate_totals(self):
        """Calculate all totals for this invoice"""
        from decimal import Decimal

        # Calculate subtotal from items
        subtotal = sum(item.line_total for item in self.invoice_items.all()) or Decimal('0')

        # Apply discount
        if self.discount_percentage > 0:
            discount_amount = subtotal * (self.discount_percentage / Decimal('100'))
        else:
            # Ensure discount_amount is Decimal
            discount_amount = Decimal(str(self.discount_amount)) if self.discount_amount else Decimal('0')

        subtotal_after_discount = subtotal - discount_amount

        # Calculate tax
        total_tax = Decimal('0')
        cgst_amount = Decimal('0')
        sgst_amount = Decimal('0')
        igst_amount = Decimal('0')

        if self.gst_type != 'exempt':
            for item in self.invoice_items.all():
                item_total = item.line_total
                item_tax = item_total * (item.gst_rate / Decimal('100'))
                total_tax += item_tax

                if self.gst_type == 'cgst_sgst':
                    cgst_amount += item_tax / Decimal('2')
                    sgst_amount += item_tax / Decimal('2')
                else:  # igst
                    igst_amount += item_tax

        # Calculate final total (ensure all values are Decimal)
        shipping_charges = Decimal(str(self.shipping_charges)) if self.shipping_charges else Decimal('0')
        other_charges = Decimal(str(self.other_charges)) if self.other_charges else Decimal('0')
        total_with_charges = subtotal_after_discount + shipping_charges + other_charges
        total_amount = total_with_charges + total_tax

        # Update fields
        self.subtotal = subtotal_after_discount
        self.discount_amount = discount_amount
        self.total_tax = total_tax
        self.cgst_amount = cgst_amount
        self.sgst_amount = sgst_amount
        self.igst_amount = igst_amount
        self.total_amount = total_amount
        # Ensure proper Decimal conversion for outstanding amount
        paid_amount = Decimal(str(self.paid_amount)) if self.paid_amount is not None else Decimal('0')
        self.outstanding_amount = total_amount - paid_amount

        # Save without triggering calculate_totals again
        super().save(update_fields=[
            'subtotal', 'total_tax', 'total_amount', 'discount_amount',
            'cgst_amount', 'sgst_amount', 'igst_amount', 'outstanding_amount'
        ])
    
    def reject_invoice(self, rejection_reason, rejected_by_user):
        """Reject this invoice and update related documents"""
        from django.utils import timezone
        
        # Mark as rejected
        self.is_rejected = True
        self.rejection_reason = rejection_reason
        self.rejected_by = rejected_by_user
        self.rejected_at = timezone.now()
        self.save()
        
        # Update related PO balance tracking (remove this invoice's impact)
        if self.purchase_order:
            self.purchase_order.update_balance_tracking()
        
        # Update related quotation balance tracking (remove this invoice's impact)
        if self.quotation:
            self.quotation.update_balance_tracking()
    
    @property
    def can_be_rejected(self):
        """Check if this invoice can be rejected"""
        return not self.is_rejected and self.payment_status not in ['paid']

    def _update_po_status_based_on_completion(self):
        """Update PO status based on invoice completion percentage"""
        if not self.purchase_order:
            return
            
        po = self.purchase_order
        completion_percentage = po.invoice_completion_percentage
        
        if completion_percentage == 0:
            po.status = 'active'  # Can raise proforma invoices
        elif completion_percentage < 100:
            po.status = 'partially_completed'  # Can raise tax invoices
        else:
            po.status = 'completed'  # All invoices raised
            
        po.save(update_fields=['status'])

    @property
    def customer_details(self):
        """Get customer details in dictionary format for PDF generation"""
        return {
            'name': self.customer.name,
            'address': self.customer.billing_address_line1,
            'city': self.customer.billing_city,
            'state': self.customer.billing_state,
            'pincode': self.customer.billing_pincode,
            'phone': self.customer.phone,
            'email': self.customer.email,
            'gst_number': self.customer.gstin,
        }


class Payment(models.Model):
    """World-Class Payment Tracking System - Links payments to specific invoice numbers or direct customer payments"""

    PAYMENT_METHOD_CHOICES = [
        ('cash', 'Cash'),
        ('bank_transfer', 'Bank Transfer'),
        ('cheque', 'Cheque'),
        ('credit_card', 'Credit Card'),
        ('debit_card', 'Debit Card'),
        ('upi', 'UPI'),
        ('net_banking', 'Net Banking'),
        ('rtgs', 'RTGS'),
        ('neft', 'NEFT'),
        ('imps', 'IMPS'),
        ('other', 'Other'),
    ]

    PAYMENT_STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('completed', 'Completed'),
        ('failed', 'Failed'),
        ('cancelled', 'Cancelled'),
        ('refunded', 'Refunded'),
    ]

    PAYMENT_TYPE_CHOICES = [
        ('invoice', 'Invoice Payment'),
        ('direct', 'Direct Payment'),
        ('tds_only', 'TDS Only Payment'),
    ]

    # Basic Information
    company = models.ForeignKey(Company, on_delete=models.CASCADE)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    purchase_order = models.ForeignKey(PurchaseOrder, on_delete=models.CASCADE, related_name='payments', null=True, blank=True)

    # Payment Type
    payment_type = models.CharField(max_length=20, choices=PAYMENT_TYPE_CHOICES, default='invoice', help_text='Type of payment - linked to invoice or direct')
    payment_purpose = models.CharField(max_length=100, blank=True, help_text='Purpose of direct payment (memo, penalty, incentive, complimentary, etc.)')

    # Invoice Linking (Optional for direct payments)
    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE, related_name='payments', null=True, blank=True, help_text='Invoice this payment is for (optional for direct payments)')
    proforma_invoice = models.ForeignKey(ProformaInvoice, on_delete=models.CASCADE, related_name='payments', null=True, blank=True, help_text='Proforma invoice this payment is for (optional for direct payments)')

    # Payment Details
    payment_number = models.CharField(max_length=50, db_index=True)
    payment_date = models.DateField()
    amount = models.DecimalField(max_digits=15, decimal_places=2)  # Keep for backward compatibility
    gross_payment_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00, help_text="Gross amount customer is paying")
    payment_method = models.CharField(max_length=20, choices=PAYMENT_METHOD_CHOICES)

    # CA-Level TDS Fields (Professional Accounting)
    tds_applicable = models.BooleanField(default=False, help_text="Whether TDS applies to this payment")
    tds_rate = models.DecimalField(max_digits=5, decimal_places=2, default=0.00, help_text="TDS rate percentage")
    tds_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00, help_text="TDS amount deducted")
    net_amount_received = models.DecimalField(max_digits=15, decimal_places=2, default=0.00, help_text="Amount received after TDS deduction")
    tds_deposited = models.BooleanField(default=False, help_text="Whether TDS has been deposited to government")
    tds_certificate_received = models.BooleanField(default=False, help_text="Whether TDS certificate (Form 16A) has been received")
    tds_section = models.CharField(max_length=20, blank=True, help_text="TDS section (194C, 194J, etc.)")
    
    # Additional Indian Compliance TDS Fields
    tds_section_code = models.CharField(max_length=10, blank=True, help_text="TDS section code (194A, 194C, etc.)")
    tds_rate_applied = models.DecimalField(max_digits=5, decimal_places=2, default=0.00, help_text="TDS rate applied")
    tds_certificate_issued = models.BooleanField(default=False)
    form16a_number = models.CharField(max_length=50, blank=True, help_text="Form 16A certificate number")
    tds_deposited_date = models.DateField(null=True, blank=True, help_text="Date when TDS was deposited")
    tds_challan_number = models.CharField(max_length=50, blank=True, help_text="TDS challan number")

    # CA-Level TDS Tracking Fields (Professional Accounting)
    ca_name = models.CharField(max_length=100, blank=True, help_text="Name of Chartered Accountant")
    ca_firm = models.CharField(max_length=200, blank=True, help_text="CA Firm name")
    ca_membership_number = models.CharField(max_length=20, blank=True, help_text="ICAI membership number")
    submitted_to_ca_date = models.DateField(null=True, blank=True, help_text="Date when TDS certificate was submitted to CA")
    ca_acknowledgment_number = models.CharField(max_length=50, blank=True, help_text="CA acknowledgment/reference number")
    ca_submission_status = models.CharField(
        max_length=20,
        choices=[
            ('not_submitted', 'Not Submitted'),
            ('submitted', 'Submitted to CA'),
            ('acknowledged', 'Acknowledged by CA'),
            ('returned', 'Returned by CA'),
        ],
        default='not_submitted',
        help_text="Status of TDS certificate submission to CA"
    )
    ca_notes = models.TextField(blank=True, help_text="Notes about CA submission, follow-ups, quarterly filings, etc.")

    # Payment Reference Information
    reference_number = models.CharField(max_length=100, blank=True, help_text="Bank reference, cheque number, etc.")
    transaction_id = models.CharField(max_length=100, blank=True, help_text="Transaction ID from payment gateway")
    bank_name = models.CharField(max_length=100, blank=True)

    # Status and Notes
    status = models.CharField(max_length=20, choices=PAYMENT_STATUS_CHOICES, default='completed')
    notes = models.TextField(blank=True)

    # Audit fields
    created_by = models.ForeignKey(CompanyServiceUser, on_delete=models.SET_NULL, null=True, related_name='created_payments')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'finance_payments'
        ordering = ['-payment_date', '-created_at']
        unique_together = ['company', 'payment_number']
        indexes = [
            models.Index(fields=['company', 'payment_number'], name='finance_pay_company_no_idx'),
        ]

    def __str__(self):
        if self.payment_type == 'direct':
            purpose = f" - {self.payment_purpose}" if self.payment_purpose else ""
            return escape(f"{self.payment_number} - ₹{self.amount} - Direct Payment{purpose}")
        invoice_info = f"INV: {self.invoice.invoice_number}" if self.invoice else f"PI: {self.proforma_invoice.proforma_number}" if self.proforma_invoice else "No Invoice"
        return escape(f"{self.payment_number} - ₹{self.amount} - {invoice_info}")

    def save(self, *args, **kwargs):
        # Generate payment number if not provided
        if not self.payment_number:
            try:
                from authentication.utils import generate_auto_code
                self.payment_number = generate_auto_code(self.company.id, 'payment')
            except Exception as e:
                # Fallback to old system if auto-code fails
                latest_payment = Payment.objects.filter(
                    company=self.company
                ).order_by('-created_at').first()

                if latest_payment and latest_payment.payment_number:
                    try:
                        parts = latest_payment.payment_number.split('-')
                        if len(parts) == 3 and parts[0] == 'PAY':
                            year = parts[1]
                            number = int(parts[2])
                            current_year = timezone.now().year

                            if int(year) == current_year:
                                new_number = number + 1
                            else:
                                new_number = 1

                            self.payment_number = f"PAY-{current_year}-{new_number:06d}"
                        else:
                            self.payment_number = f"PAY-{timezone.now().year}-000001"
                    except (ValueError, IndexError):
                        self.payment_number = f"PAY-{timezone.now().year}-000001"
                else:
                    self.payment_number = f"PAY-{timezone.now().year}-000001"

        # World-Class TDS Calculation - Handle both old and new field structures
        from decimal import Decimal
        
        # Use gross_payment_amount if provided, otherwise fall back to amount
        amount = Decimal(str(self.gross_payment_amount)) if self.gross_payment_amount and self.gross_payment_amount > 0 else Decimal(str(self.amount)) if self.amount is not None else Decimal('0')
        tds_percentage = Decimal(str(self.tds_rate)) if self.tds_rate is not None else Decimal('0')
        tds_amount = Decimal(str(self.tds_amount)) if self.tds_amount is not None else Decimal('0')
        net_amount_received = Decimal(str(self.net_amount_received)) if self.net_amount_received is not None else Decimal('0')
        
        # Ensure backward compatibility - set gross_payment_amount if not set
        if not self.gross_payment_amount or self.gross_payment_amount == 0:
            self.gross_payment_amount = amount
        
        # Ensure TDS applicable flag is set based on TDS amount/rate
        if not hasattr(self, 'tds_applicable') or self.tds_applicable is None:
            self.tds_applicable = tds_amount > 0 or tds_percentage > 0
        # Force True if TDS was actually deducted, regardless of flag
        if tds_amount > 0:
            self.tds_applicable = True
        
        # Resolve base amount (subtotal) for TDS calculation.
        # TDS is always on the base/subtotal amount, never on GST/total.
        # Use invoice subtotal when available; fall back to gross payment amount.
        invoice_subtotal = Decimal('0')
        if self.invoice and self.invoice.subtotal:
            invoice_subtotal = Decimal(str(self.invoice.subtotal))
        elif self.proforma_invoice and self.proforma_invoice.subtotal:
            invoice_subtotal = Decimal(str(self.proforma_invoice.subtotal))
        tds_base = invoice_subtotal if invoice_subtotal > 0 else amount

        # If TDS is applicable, ensure rate is set (back-calculate from base, not gross)
        if self.tds_applicable and tds_percentage == 0 and tds_base > 0 and tds_amount > 0:
            self.tds_rate = (tds_amount / tds_base) * Decimal('100')
            tds_percentage = self.tds_rate

        # Calculate TDS amounts based on CA-level logic
        if self.tds_applicable:
            # Skip TDS calculation for TDS-only payments (amount=0, tds_amount>0)
            if amount == 0 and tds_amount > 0 and hasattr(self, 'payment_type') and self.payment_type == 'tds_only':
                # TDS-only payment - don't recalculate, keep as set
                pass
            elif tds_amount > 0 and net_amount_received > 0:
                # Frontend already computed correct values — trust them
                self.tds_amount = tds_amount
                self.net_amount_received = net_amount_received
                # Back-calculate rate from base amount (subtotal), not gross
                if tds_base > 0:
                    self.tds_rate = (tds_amount / tds_base) * Decimal('100')
            elif tds_percentage > 0 and tds_base > 0:
                # Only rate provided — calculate TDS on base amount (subtotal)
                self.tds_amount = (tds_base * tds_percentage) / Decimal('100')
                self.net_amount_received = amount - self.tds_amount
            elif tds_amount > 0:
                self.net_amount_received = amount - tds_amount
                if tds_base > 0:
                    self.tds_rate = (tds_amount / tds_base) * Decimal('100')
            else:
                self.tds_amount = Decimal('0')
                self.net_amount_received = amount
        else:
            # No TDS
            self.tds_amount = Decimal('0')
            self.net_amount_received = amount
            self.tds_rate = Decimal('0')

        super().save(*args, **kwargs)

        # Update related invoice/proforma payment status for invoice and tds_only payments
        if self.payment_type in ('invoice', 'tds_only'):
            self.update_invoice_payment_status()

    def update_invoice_payment_status(self):
        """Update invoice outstanding.
        TDS logic: TDS-only payments reduce outstanding immediately (customer has already deducted it).
        For regular payments with TDS, net_amount_received counts immediately; TDS portion counts
        only when tds_certificate_received=True.
        """
        from decimal import Decimal

        def calc_paid(payments_qs, invoice_obj=None):
            """Sum what is actually settled: net received + TDS only if cert received.
            Supports both payment-level TDS (tds_amount > 0) and invoice-level TDS
            (invoice.tds_applicable=True, payment.tds_amount=0).
            """
            total = Decimal('0')
            for p in payments_qs.filter(status='completed'):
                # For TDS-only payments, count TDS amount immediately toward outstanding
                if getattr(p, 'payment_type', None) == 'tds_only':
                    total += Decimal(str(p.tds_amount or 0))
                    continue
                    
                net = Decimal(str(p.net_amount_received or 0))
                tds = Decimal(str(p.tds_amount or 0))

                if tds > 0:
                    # Payment-level TDS: count TDS only when cert received
                    total += net + (tds if p.tds_certificate_received else Decimal('0'))
                elif invoice_obj and getattr(invoice_obj, 'tds_applicable', False) and getattr(invoice_obj, 'tds_rate', 0):
                    # Invoice-level TDS: derive TDS from deposits on this payment
                    from django.db.models import Sum as DSum
                    cert_received = p.tds_deposits.filter(certificate_received=True).aggregate(
                        t=DSum('amount'))['t'] or Decimal('0')
                    total += net + cert_received
                else:
                    # No TDS — use gross
                    gross = Decimal(str(p.gross_payment_amount or p.amount or 0))
                    total += gross
            return total


        if self.invoice:
            direct_payments = calc_paid(self.invoice.payments, self.invoice)

            total_paid = direct_payments
            invoice_total = Decimal(str(self.invoice.total_amount or 0))

            self.invoice.paid_amount = total_paid
            self.invoice.outstanding_amount = invoice_total - total_paid

            if self.invoice.outstanding_amount <= 0:
                self.invoice.payment_status = 'paid'
            elif total_paid > 0:
                self.invoice.payment_status = 'partially_paid'
            else:
                self.invoice.payment_status = 'unpaid'
            if (self.invoice.payment_status == 'unpaid' and
                    self.invoice.due_date and self.invoice.due_date < timezone.now().date()):
                self.invoice.payment_status = 'overdue'

            self.invoice.last_payment_date = self.payment_date
            self.invoice.save(update_fields=['paid_amount', 'outstanding_amount', 'payment_status', 'last_payment_date'])

        elif self.proforma_invoice:
            total_payments = calc_paid(self.proforma_invoice.payments)
            proforma_total = Decimal(str(self.proforma_invoice.total_amount or 0))

            self.proforma_invoice.paid_amount = total_payments
            self.proforma_invoice.outstanding_amount = proforma_total - total_payments

            if abs(self.proforma_invoice.outstanding_amount) <= Decimal('0.01'):
                self.proforma_invoice.payment_status = 'paid'
            elif total_payments > Decimal('0'):
                self.proforma_invoice.payment_status = 'partially_paid'
            else:
                self.proforma_invoice.payment_status = 'unpaid'

            self.proforma_invoice.last_payment_date = self.payment_date
            self.proforma_invoice.save(update_fields=['paid_amount', 'outstanding_amount', 'payment_status', 'last_payment_date'])

    def delete(self, *args, **kwargs):
        """Override delete to update invoice payment status after deletion"""
        invoice = self.invoice
        proforma_invoice = self.proforma_invoice
        super().delete(*args, **kwargs)
        from decimal import Decimal

        def calc_paid(payments_qs):
            total = Decimal('0')
            for p in payments_qs.filter(status='completed'):
                # For TDS-only payments, count TDS amount immediately toward outstanding
                if getattr(p, 'payment_type', None) == 'tds_only':
                    total += Decimal(str(p.tds_amount or 0))
                    continue
                    
                net = Decimal(str(p.net_amount_received or 0))
                tds = Decimal(str(p.tds_amount or 0))
                if tds > 0:
                    total += net + (tds if p.tds_certificate_received else Decimal('0'))
                else:
                    total += Decimal(str(p.gross_payment_amount or p.amount or 0))
            return total

        if invoice:
            direct_payments = calc_paid(invoice.payments)
            total_paid = direct_payments
            invoice.paid_amount = total_paid
            invoice_total = Decimal(str(invoice.total_amount or 0))
            invoice.outstanding_amount = invoice_total - total_paid
            
            if invoice.outstanding_amount <= 0:
                invoice.payment_status = 'paid'
            elif total_paid > 0:
                invoice.payment_status = 'partially_paid'
            else:
                invoice.payment_status = 'unpaid'
            # Overdue only applies when fully unpaid and past due date
            if (invoice.payment_status == 'unpaid' and
                    invoice.due_date and invoice.due_date < timezone.now().date()):
                invoice.payment_status = 'overdue'
            
            # Get last payment date from remaining payments
            last_payment = invoice.payments.filter(status='completed').order_by('-payment_date').first()
            invoice.last_payment_date = last_payment.payment_date if last_payment else None
            
            invoice.save(update_fields=['paid_amount', 'outstanding_amount', 'payment_status', 'last_payment_date'])
        
        elif proforma_invoice:
            total_payments = calc_paid(proforma_invoice.payments)
            proforma_total = Decimal(str(proforma_invoice.total_amount or 0))
            proforma_invoice.paid_amount = total_payments
            proforma_invoice.outstanding_amount = proforma_total - total_payments
            if abs(proforma_invoice.outstanding_amount) <= Decimal('0.01'):
                proforma_invoice.payment_status = 'paid'
            elif total_payments > Decimal('0'):
                proforma_invoice.payment_status = 'partially_paid'
            else:
                proforma_invoice.payment_status = 'unpaid'
            last_payment = proforma_invoice.payments.filter(status='completed').order_by('-payment_date').first()
            proforma_invoice.last_payment_date = last_payment.payment_date if last_payment else None
            proforma_invoice.save(update_fields=['paid_amount', 'outstanding_amount', 'payment_status', 'last_payment_date'])


class InvoiceItem(models.Model):
    """Individual items in an Invoice"""

    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE, related_name='invoice_items')
    product = models.ForeignKey(Product, on_delete=models.CASCADE)

    # Item details (captured at time of invoice creation)
    product_name = models.CharField(max_length=255)
    product_code = models.CharField(max_length=50)
    description = models.TextField(blank=True)
    hsn_sac_code = models.CharField(max_length=20, blank=True)

    # Pricing and quantity
    quantity = models.DecimalField(max_digits=12, decimal_places=2)
    unit = models.CharField(max_length=10)
    unit_price = models.DecimalField(max_digits=12, decimal_places=2)
    line_total = models.DecimalField(max_digits=15, decimal_places=2)

    # Tax information
    gst_rate = models.DecimalField(max_digits=5, decimal_places=2)

    # Line item order
    line_number = models.PositiveIntegerField(default=1)
    
    # Claim tracking (for invoices created from PO/Quotation)
    po_item = models.ForeignKey('PurchaseOrderItem', on_delete=models.SET_NULL, null=True, blank=True, related_name='invoice_items')
    claimed_quantity_display = models.CharField(max_length=50, blank=True, help_text="Display value for claimed quantity (e.g., '10%' or '5 Nos')")
    claim_type = models.CharField(max_length=20, blank=True, choices=[('percentage', 'Percentage'), ('unit', 'Unit'), ('as_per_unit', 'As Per Unit')], help_text="Type of claim")
    is_claimed = models.BooleanField(default=False, help_text="Whether this line item has been claimed")
    claimed_percentage = models.DecimalField(max_digits=5, decimal_places=2, default=0, help_text="Percentage claimed if claim_type is percentage")

    class Meta:
        db_table = 'finance_invoice_items'
        ordering = ['line_number']
        unique_together = ['invoice', 'line_number']

    def __str__(self):
        return escape(f"{self.invoice.invoice_number} - {self.product_name}")

    @property
    def rate(self):
        """Alias for unit_price to match PDF generator expectations"""
        return self.unit_price

    @property
    def amount(self):
        """Calculate amount before tax (quantity * unit_price)"""
        return self.quantity * self.unit_price

    @property
    def tax_amount(self):
        """Calculate tax amount"""
        from decimal import Decimal
        amount = self.quantity * self.unit_price
        return amount * (self.gst_rate / Decimal('100'))

    def save(self, *args, **kwargs):
        skip_totals_calculation = kwargs.pop('skip_totals_calculation', False)

        # Calculate line total
        self.line_total = self.quantity * self.unit_price

        super().save(*args, **kwargs)

        # Recalculate invoice totals only if not in bulk creation
        if not skip_totals_calculation:
            self.invoice.calculate_totals()


# ============================================================================
# PURCHASE & EXPENSE MANAGEMENT MODELS - NEW FUNCTIONALITY
# ============================================================================

class Vendor(models.Model):
    """Vendor/Supplier model for purchase management"""
    VENDOR_TYPE_CHOICES = [
        ('individual', 'Individual'),
        ('business', 'Business'),
        ('government', 'Government'),
        ('ngo', 'NGO/Non-Profit'),
    ]

    # Basic Information
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='vendors')
    vendor_code = models.CharField(max_length=20, unique=True, blank=True)
    name = models.CharField(max_length=255)
    vendor_type = models.CharField(max_length=20, choices=VENDOR_TYPE_CHOICES, default='business')
    
    # Contact Information
    contact_person = models.CharField(max_length=100, blank=True)
    email = models.EmailField(blank=True)
    phone = models.CharField(max_length=15, blank=True)
    mobile = models.CharField(max_length=15, blank=True)
    website = models.URLField(blank=True)
    
    # Address Information
    address_line1 = models.CharField(max_length=255, blank=True)
    address_line2 = models.CharField(max_length=255, blank=True)
    city = models.CharField(max_length=100, blank=True)
    state = models.CharField(max_length=100, blank=True)
    pincode = models.CharField(max_length=10, blank=True)
    country = models.CharField(max_length=100, default='India')
    
    # Tax Information
    gstin = models.CharField(max_length=15, blank=True)
    pan_number = models.CharField(max_length=10, blank=True)
    
    # Banking Information
    bank_name = models.CharField(max_length=100, blank=True)
    bank_account_number = models.CharField(max_length=20, blank=True)
    bank_ifsc_code = models.CharField(max_length=11, blank=True)
    account_holder_name = models.CharField(max_length=200, blank=True)
    
    # Payment Terms
    payment_terms = models.CharField(max_length=100, default='Net 30')
    credit_limit = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    
    # Additional Information
    notes = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    
    # Audit fields
    created_by = models.ForeignKey(CompanyServiceUser, on_delete=models.SET_NULL, null=True, related_name='created_vendors')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'finance_vendors'
        ordering = ['-created_at']
        unique_together = ['company', 'vendor_code']

    def __str__(self):
        return escape(f"{self.vendor_code} - {self.name}")

    def save(self, *args, **kwargs):
        if not self.vendor_code:
            try:
                from authentication.utils import generate_auto_code
                self.vendor_code = generate_auto_code(self.company.id, 'vendor')
            except Exception:
                last_vendor = Vendor.objects.filter(
                    company=self.company,
                    vendor_code__startswith='VEN-'
                ).order_by('-id').first()
                if last_vendor:
                    last_number = int(last_vendor.vendor_code.split('-')[-1])
                    self.vendor_code = f"VEN-{last_number + 1:06d}"
                else:
                    self.vendor_code = "VEN-000001"
        super().save(*args, **kwargs)


class PurchaseRequest(models.Model):
    """Purchase Request - We send to vendors"""
    STATUS_CHOICES = [
        ('draft', 'Draft'),
        ('sent', 'Sent to Vendor'),
        ('approved', 'Approved by Vendor'),
        ('rejected', 'Rejected'),
        ('converted', 'Converted to Invoice'),
    ]

    GST_TYPE_CHOICES = [
        ('igst', 'IGST (Inter-State)'),
        ('cgst_sgst', 'CGST + SGST (Intra-State)'),
        ('exempt', 'GST Exempt'),
    ]
    
    # Basic Information
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='purchase_requests')
    vendor = models.ForeignKey(Vendor, on_delete=models.CASCADE, related_name='purchase_requests')
    request_number = models.CharField(max_length=50, db_index=True)
    
    # Request Details
    request_date = models.DateField()
    required_by_date = models.DateField(null=True, blank=True)
    reference = models.CharField(max_length=100, blank=True)
    
    # GST Information
    gst_type = models.CharField(max_length=20, choices=GST_TYPE_CHOICES, default='igst')
    vendor_gstin = models.CharField(max_length=15, blank=True)
    company_gstin = models.CharField(max_length=15, blank=True)
    
    # Financial Totals
    subtotal = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    total_tax = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    total_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    
    # Tax Breakdown
    cgst_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    sgst_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    igst_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    
    # Additional Charges
    discount_percentage = models.DecimalField(max_digits=5, decimal_places=2, default=0.00)
    discount_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    shipping_charges = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    other_charges = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    
    # Status and Notes
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft')
    notes = models.TextField(blank=True)
    terms_and_conditions = models.TextField(blank=True)
    
    # Audit fields
    created_by = models.ForeignKey(CompanyServiceUser, on_delete=models.SET_NULL, null=True, related_name='created_purchase_requests')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'finance_purchase_requests'
        ordering = ['-created_at']
        unique_together = ['company', 'request_number']
        indexes = [
            models.Index(fields=['company', 'request_number'], name='finance_pr_company_no_idx'),
        ]

    def __str__(self):
        return escape(f"{self.request_number} - {self.vendor.name}")

    def save(self, *args, **kwargs):
        if not self.request_number:
            try:
                from authentication.utils import generate_auto_code
                self.request_number = generate_auto_code(self.company.id, 'purchase_request')
            except Exception:
                from datetime import datetime
                year = datetime.now().year
                last_request = PurchaseRequest.objects.filter(
                    company=self.company,
                    request_number__startswith=f"PR-{year}"
                ).order_by('-id').first()
                if last_request:
                    last_number = int(last_request.request_number.split('-')[-1])
                    self.request_number = f"PR-{year}-{last_number + 1:06d}"
                else:
                    self.request_number = f"PR-{year}-000001"
        super().save(*args, **kwargs)


class PurchaseRequestItem(models.Model):
    """Individual items in a Purchase Request"""
    purchase_request = models.ForeignKey(PurchaseRequest, on_delete=models.CASCADE, related_name='request_items')
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    
    # Item details
    product_name = models.CharField(max_length=255)
    product_code = models.CharField(max_length=50)
    description = models.TextField(blank=True)
    hsn_sac_code = models.CharField(max_length=20, blank=True)
    
    # Pricing and quantity
    quantity = models.DecimalField(max_digits=12, decimal_places=2)
    unit = models.CharField(max_length=10)
    unit_price = models.DecimalField(max_digits=12, decimal_places=2)
    line_total = models.DecimalField(max_digits=15, decimal_places=2)
    
    # Tax information
    gst_rate = models.DecimalField(max_digits=5, decimal_places=2)
    
    # Line item order
    line_number = models.PositiveIntegerField(default=1)

    class Meta:
        db_table = 'finance_purchase_request_items'
        ordering = ['line_number']
        unique_together = ['purchase_request', 'line_number']

    def __str__(self):
        return escape(f"{self.purchase_request.request_number} - {self.product_name}")

    def save(self, *args, **kwargs):
        if self.product:
            self.product_name = self.product.name
            self.product_code = self.product.product_code
            self.description = self.product.description
            self.unit = self.product.unit_ref.code if self.product.unit_ref else self.product.unit
            self.gst_rate = self.product.gst_rate
            
            if self.product.hsn_code:
                self.hsn_sac_code = self.product.hsn_code.code
            elif self.product.sac_code:
                self.hsn_sac_code = self.product.sac_code.code
        
        self.line_total = self.quantity * self.unit_price
        super().save(*args, **kwargs)


class VendorInvoice(models.Model):
    """Vendor Invoice - We receive from vendors"""
    PAYMENT_STATUS_CHOICES = [
        ('unpaid', 'Unpaid'),
        ('partially_paid', 'Partially Paid'),
        ('paid', 'Paid'),
        ('overdue', 'Overdue'),
    ]

    STATUS_CHOICES = [
        ('draft', 'Draft'),
        ('received', 'Received'),
        ('verified', 'Verified'),
        ('approved', 'Approved for Payment'),
        ('paid', 'Paid'),
        ('cancelled', 'Cancelled'),
    ]
    
    # Basic Information
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='vendor_invoices')
    vendor = models.ForeignKey(Vendor, on_delete=models.CASCADE, related_name='invoices')
    purchase_request = models.ForeignKey(PurchaseRequest, on_delete=models.SET_NULL, null=True, blank=True, related_name='vendor_invoices')
    
    # Invoice details from vendor
    vendor_invoice_number = models.CharField(max_length=100, db_index=True)
    vendor_invoice_date = models.DateField()
    our_reference_number = models.CharField(max_length=50, db_index=True)
    
    # Due date
    due_date = models.DateField()
    
    # GST Information
    gst_type = models.CharField(max_length=10, choices=[
        ('igst', 'IGST'),
        ('cgst_sgst', 'CGST + SGST'),
        ('exempt', 'GST Exempt')
    ], default='igst')
    
    # Financial Information
    subtotal = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    total_tax = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    total_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    
    # Tax Breakdown
    cgst_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    sgst_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    igst_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    
    # Payment tracking
    paid_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    outstanding_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    payment_status = models.CharField(max_length=20, choices=PAYMENT_STATUS_CHOICES, default='unpaid')
    last_payment_date = models.DateField(null=True, blank=True)
    
    # Status
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft')
    
    # File attachment
    invoice_file = models.FileField(upload_to='vendor_invoices/', null=True, blank=True)
    
    # Notes
    notes = models.TextField(blank=True)
    
    # Audit fields
    created_by = models.ForeignKey(CompanyServiceUser, on_delete=models.SET_NULL, null=True, related_name='created_vendor_invoices')
    verified_by = models.ForeignKey(CompanyServiceUser, on_delete=models.SET_NULL, null=True, blank=True, related_name='verified_vendor_invoices')
    approved_by = models.ForeignKey(CompanyServiceUser, on_delete=models.SET_NULL, null=True, blank=True, related_name='approved_vendor_invoices')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'finance_vendor_invoices'
        ordering = ['-created_at']
        unique_together = ['company', 'our_reference_number']
        constraints = [
            models.UniqueConstraint(
                fields=['company', 'vendor_invoice_number'],
                name='finance_vendor_invoice_company_number_uniq'
            ),
        ]
        indexes = [
            models.Index(fields=['company', 'vendor_invoice_number'], name='fin_vi_no_idx'),
            models.Index(fields=['company', 'our_reference_number'], name='finance_vi_company_ref_idx'),
        ]

    def __str__(self):
        return escape(f"{self.our_reference_number} - {self.vendor.name}")

    def save(self, *args, **kwargs):
        if not self.our_reference_number:
            try:
                from authentication.utils import generate_auto_code
                self.our_reference_number = generate_auto_code(self.company.id, 'vendor_invoice')
            except Exception:
                from datetime import datetime
                year = datetime.now().year
                last_invoice = VendorInvoice.objects.filter(
                    company=self.company,
                    our_reference_number__startswith=f"VI-{year}"
                ).order_by('-id').first()
                if last_invoice:
                    last_number = int(last_invoice.our_reference_number.split('-')[-1])
                    self.our_reference_number = f"VI-{year}-{last_number + 1:06d}"
                else:
                    self.our_reference_number = f"VI-{year}-000001"
        
        # Calculate outstanding amount
        from decimal import Decimal
        total_amount = Decimal(str(self.total_amount)) if self.total_amount else Decimal('0')
        paid_amount = Decimal(str(self.paid_amount)) if self.paid_amount else Decimal('0')
        self.outstanding_amount = total_amount - paid_amount
        
        # Update payment status
        if self.paid_amount == 0:
            self.payment_status = 'unpaid'
        elif self.paid_amount >= self.total_amount:
            self.payment_status = 'paid'
        else:
            self.payment_status = 'partially_paid'
        
        # Check if overdue
        if self.payment_status != 'paid' and self.due_date < timezone.now().date():
            self.payment_status = 'overdue'
        
        super().save(*args, **kwargs)


class VendorInvoiceItem(models.Model):
    """Individual items in a Vendor Invoice"""
    vendor_invoice = models.ForeignKey(VendorInvoice, on_delete=models.CASCADE, related_name='invoice_items')
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    
    # Item details
    product_name = models.CharField(max_length=255)
    product_code = models.CharField(max_length=50)
    description = models.TextField(blank=True)
    hsn_sac_code = models.CharField(max_length=20, blank=True)
    
    # Pricing and quantity
    quantity = models.DecimalField(max_digits=12, decimal_places=2)
    unit = models.CharField(max_length=10)
    unit_price = models.DecimalField(max_digits=12, decimal_places=2)
    line_total = models.DecimalField(max_digits=15, decimal_places=2)
    
    # Tax information
    gst_rate = models.DecimalField(max_digits=5, decimal_places=2)
    
    # Line item order
    line_number = models.PositiveIntegerField(default=1)

    class Meta:
        db_table = 'finance_vendor_invoice_items'
        ordering = ['line_number']
        unique_together = ['vendor_invoice', 'line_number']

    def __str__(self):
        return escape(f"{self.vendor_invoice.our_reference_number} - {self.product_name}")

    def save(self, *args, **kwargs):
        if self.product:
            self.product_name = self.product.name
            self.product_code = self.product.product_code
            self.description = self.product.description
            self.unit = self.product.unit_ref.code if self.product.unit_ref else self.product.unit
            self.gst_rate = self.product.gst_rate
            
            if self.product.hsn_code:
                self.hsn_sac_code = self.product.hsn_code.code
            elif self.product.sac_code:
                self.hsn_sac_code = self.product.sac_code.code
        
        self.line_total = self.quantity * self.unit_price
        super().save(*args, **kwargs)


class PurchasePayment(models.Model):
    """Payments made to vendors"""
    PAYMENT_METHOD_CHOICES = [
        ('bank_transfer', 'Bank Transfer'),
        ('cheque', 'Cheque'),
        ('cash', 'Cash'),
        ('upi', 'UPI'),
        ('rtgs', 'RTGS'),
        ('neft', 'NEFT'),
        ('imps', 'IMPS'),
        ('other', 'Other'),
    ]

    PAYMENT_STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('completed', 'Completed'),
        ('failed', 'Failed'),
        ('cancelled', 'Cancelled'),
    ]
    
    # Basic Information
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='purchase_payments')
    vendor = models.ForeignKey(Vendor, on_delete=models.CASCADE, related_name='payments')
    vendor_invoice = models.ForeignKey(VendorInvoice, on_delete=models.CASCADE, related_name='payments')
    
    # Payment Details
    payment_number = models.CharField(max_length=50, db_index=True)
    payment_date = models.DateField()
    amount = models.DecimalField(max_digits=15, decimal_places=2)
    payment_method = models.CharField(max_length=20, choices=PAYMENT_METHOD_CHOICES)
    
    # TDS (Tax Deducted at Source)
    tds_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    tds_percentage = models.DecimalField(max_digits=5, decimal_places=2, default=0.00)
    tds_section = models.CharField(max_length=20, blank=True)
    net_amount_paid = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    
    # Payment Reference
    reference_number = models.CharField(max_length=100, blank=True)
    transaction_id = models.CharField(max_length=100, blank=True)
    bank_name = models.CharField(max_length=100, blank=True)
    
    # Status and Notes
    status = models.CharField(max_length=20, choices=PAYMENT_STATUS_CHOICES, default='completed')
    notes = models.TextField(blank=True)
    
    # Audit fields
    created_by = models.ForeignKey(CompanyServiceUser, on_delete=models.SET_NULL, null=True, related_name='created_purchase_payments')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'finance_purchase_payments'
        ordering = ['-payment_date', '-created_at']
        unique_together = ['company', 'payment_number']
        indexes = [
            models.Index(fields=['company', 'payment_number'], name='finance_pp_company_no_idx'),
        ]

    def __str__(self):
        return escape(f"{self.payment_number} - ₹{self.amount} - {self.vendor.name}")

    def save(self, *args, **kwargs):
        if not self.payment_number:
            try:
                from authentication.utils import generate_auto_code
                self.payment_number = generate_auto_code(self.company.id, 'purchase_payment')
            except Exception:
                from datetime import datetime
                year = datetime.now().year
                last_payment = PurchasePayment.objects.filter(
                    company=self.company,
                    payment_number__startswith=f"PP-{year}"
                ).order_by('-id').first()
                if last_payment:
                    last_number = int(last_payment.payment_number.split('-')[-1])
                    self.payment_number = f"PP-{year}-{last_number + 1:06d}"
                else:
                    self.payment_number = f"PP-{year}-000001"
        
        # TDS Calculation
        from decimal import Decimal
        amount = Decimal(str(self.amount)) if self.amount else Decimal('0')
        tds_percentage = Decimal(str(self.tds_percentage)) if self.tds_percentage else Decimal('0')
        
        if tds_percentage > 0:
            self.tds_amount = (amount * tds_percentage) / Decimal('100')
            self.net_amount_paid = amount - self.tds_amount
        else:
            self.net_amount_paid = amount
        
        super().save(*args, **kwargs)
        
        # Update vendor invoice payment status
        self.update_vendor_invoice_payment_status()

    def update_vendor_invoice_payment_status(self):
        """Update vendor invoice payment status"""
        from decimal import Decimal
        
        # Calculate total payments for this vendor invoice
        total_payments = self.vendor_invoice.payments.filter(status='completed').aggregate(
            total=models.Sum('amount')
        )['total'] or Decimal('0')
        
        self.vendor_invoice.paid_amount = total_payments
        invoice_total = Decimal(str(self.vendor_invoice.total_amount)) if self.vendor_invoice.total_amount else Decimal('0')
        self.vendor_invoice.outstanding_amount = invoice_total - total_payments
        
        # Update payment status
        if self.vendor_invoice.outstanding_amount <= 0:
            self.vendor_invoice.payment_status = 'paid'
            self.vendor_invoice.status = 'paid'
        elif total_payments > 0:
            self.vendor_invoice.payment_status = 'partially_paid'
        else:
            self.vendor_invoice.payment_status = 'unpaid'
        
        self.vendor_invoice.last_payment_date = self.payment_date
        self.vendor_invoice.save(update_fields=['paid_amount', 'outstanding_amount', 'payment_status', 'status', 'last_payment_date'])


class Gstr1ExportLog(models.Model):
    """Audit log for every GSTR-1 export attempt."""
    company_id = models.IntegerField(db_index=True)
    company_gstin = models.CharField(max_length=15)
    return_month = models.CharField(max_length=20)
    financial_year = models.CharField(max_length=10)
    from_date = models.DateField()
    to_date = models.DateField()
    exported_by_id = models.IntegerField()
    exported_by_name = models.CharField(max_length=255)
    exported_at = models.DateTimeField(auto_now_add=True)
    file_name = models.CharField(max_length=255)
    b2b_count = models.IntegerField(default=0)
    b2cs_count = models.IntegerField(default=0)
    cdnr_count = models.IntegerField(default=0)
    cdnra_count = models.IntegerField(default=0)
    hsn_b2b_count = models.IntegerField(default=0)
    hsn_b2c_count = models.IntegerField(default=0)
    docs_count = models.IntegerField(default=0)
    validation_status = models.CharField(max_length=20, default='passed')
    export_status = models.CharField(max_length=20, default='success')
    error_message = models.TextField(blank=True)

    class Meta:
        db_table = 'finance_gstr1_export_logs'
        ordering = ['-exported_at']

    def __str__(self):
        return f'GSTR1 {self.company_gstin} {self.return_month} by {self.exported_by_name}'


class TDSDeposit(models.Model):
    """Tracks split TDS deposits made against a single Payment's TDS amount."""

    payment = models.ForeignKey(
        Payment,
        on_delete=models.CASCADE,
        related_name='tds_deposits',
        help_text="The payment whose TDS this deposit covers"
    )
    company = models.ForeignKey(Company, on_delete=models.CASCADE)

    deposit_date = models.DateField(help_text="Date TDS was deposited to government")
    amount = models.DecimalField(max_digits=15, decimal_places=2, help_text="Amount deposited in this instalment")
    challan_number = models.CharField(max_length=50, blank=True, help_text="BSR/Challan number")
    form16a_number = models.CharField(max_length=50, blank=True, help_text="Form 16A certificate number for this deposit")
    certificate_received = models.BooleanField(default=False, help_text="Whether Form 16A received for this deposit")
    notes = models.TextField(blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'finance_tds_deposits'
        ordering = ['deposit_date', 'created_at']

    def __str__(self):
        return f"TDS Deposit ₹{self.amount} on {self.deposit_date} for {self.payment.payment_number}"

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        self._sync_payment_tds_status()

    def delete(self, *args, **kwargs):
        payment = self.payment
        super().delete(*args, **kwargs)
        self._sync_payment_tds_status(payment=payment)

    def _sync_payment_tds_status(self, payment=None):
        """Sync tds_deposited / tds_certificate_received on Payment,
        then recalculate invoice outstanding so TDS stays outstanding
        until ALL TDS is covered by cert-received deposits."""
        from decimal import Decimal
        p = payment or self.payment
        deposits = p.tds_deposits.all()

        # Use invoice-level TDS total when payment.tds_amount is 0
        invoice = p.invoice or p.proforma_invoice
        if invoice and getattr(invoice, 'tds_applicable', False) and getattr(invoice, 'tds_rate', 0):
            tds_total = (Decimal(str(invoice.subtotal or 0)) * Decimal(str(invoice.tds_rate or 0)) / 100).quantize(Decimal('0.01'))
        else:
            tds_total = Decimal(str(p.tds_amount or 0))

        total_deposited = deposits.aggregate(t=models.Sum('amount'))['t'] or Decimal('0')
        total_cert = deposits.filter(certificate_received=True).aggregate(
            t=models.Sum('amount'))['t'] or Decimal('0')

        p.tds_deposited = tds_total > 0 and total_deposited >= tds_total
        p.tds_certificate_received = tds_total > 0 and total_cert >= tds_total
        p.save(update_fields=['tds_deposited', 'tds_certificate_received'])

        # Recalculate invoice outstanding
        p.update_invoice_payment_status()
